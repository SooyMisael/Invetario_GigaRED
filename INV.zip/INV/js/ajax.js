// ==========================================================
// FUNCIÓN MEJORADA PARA CREAR NOTIFICACIONES (ÉXITO Y ERROR)
// ==========================================================
function showNotification(message, type = 'success') {
    const container = document.getElementById('notification-container');
    if (!container) return;

    // Crear el contenedor principal del toast
    const toast = document.createElement('div');
    toast.className = `notification-toast toast-${type}`; // Ej: 'notification-toast toast-success'

    // Crear el icono basado en el tipo
    const icon = document.createElement('i');
    icon.className = 'toast-icon fas';
    icon.classList.add(type === 'success' ? 'fa-check-circle' : 'fa-times-circle');

    // Crear el contenedor del mensaje
    const messageSpan = document.createElement('span');
    messageSpan.className = 'toast-message';
    messageSpan.textContent = message;

    // Crear el botón de cierre
    const closeButton = document.createElement('button');
    closeButton.className = 'toast-close';
    closeButton.innerHTML = '&times;'; // El símbolo '×'

    // Juntar todas las partes
    toast.appendChild(icon);
    toast.appendChild(messageSpan);
    toast.appendChild(closeButton);
    container.appendChild(toast);

    // Temporizador para que se cierre sola
    const timer = setTimeout(() => {
        toast.remove();
    }, 8000);

    // Hacer que el botón de cierre funcione y cancele el temporizador
    closeButton.addEventListener('click', () => {
        clearTimeout(timer); // Cancela el cierre automático
        toast.remove();
    });
}


// ==========================================================
// MANEJADOR DE FORMULARIOS AJAX (INTEGRADO CON NUEVA FUNCIÓN)
// ==========================================================
document.addEventListener("DOMContentLoaded", function(){
    const formularios_ajax = document.querySelectorAll(".FormularioAjax");

    formularios_ajax.forEach(form => {
        form.addEventListener("submit", function(e){
            e.preventDefault(); 

            const data = new FormData(this);
            const action = this.getAttribute("action");
            const method = this.getAttribute("method");

            fetch(action, { method: method, body: data })
                .then(res => {
                    if (!res.ok) throw new Error('Respuesta del servidor no fue OK');
                    return res.json();
                })
                .then(respuesta => {
                    console.log("Respuesta del servidor:", respuesta); 

                    if(respuesta.success){
                        // Llamar a la notificación de ÉXITO
                        showNotification(respuesta.message, 'success');
                        
                        if(respuesta.redirect){
                            setTimeout(() => {
                                window.location.href = respuesta.redirect;
                            }, 1500);
                        }
                    } else {
                        // Llamar a la notificación de ERROR
                        showNotification(respuesta.message, 'error');
                    }
                })
                .catch(err => {
                    console.error("Error AJAX:", err);
                    // Llamar a la notificación de ERROR para fallos de conexión
                    showNotification('Ocurrió un error de comunicación con el servidor.', 'error');
                });
        });
    });
});