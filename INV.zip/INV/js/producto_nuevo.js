function showNotification(message, type = 'success') {
    const container = document.getElementById('notification-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `notification-toast toast-${type}`;
    const icon = document.createElement('i');
    icon.className = 'toast-icon fas';
    icon.classList.add(type === 'success' ? 'fa-check-circle' : 'fa-times-circle');
    const messageSpan = document.createElement('span');
    messageSpan.className = 'toast-message';
    messageSpan.textContent = message;
    const closeButton = document.createElement('button');
    closeButton.className = 'toast-close';
    closeButton.innerHTML = '&times;';
    toast.appendChild(icon);
    toast.appendChild(messageSpan);
    toast.appendChild(closeButton);
    container.appendChild(toast);
    const timer = setTimeout(() => { toast.remove(); }, 4000);
    closeButton.addEventListener('click', () => { clearTimeout(timer); toast.remove(); });
}

const soloNumeros = (evento) => {
    const teclaPresionada = evento.key;
    const esNumero = teclaPresionada >= '0' && teclaPresionada <= '9';
    const teclasControl = ['Backspace', 'Delete', 'Tab', 'ArrowLeft', 'ArrowRight', 'Home', 'End'];
    if (!esNumero && !teclasControl.includes(teclaPresionada)) {
        evento.preventDefault();
    }
};

const soloPrecio = (evento) => {
    const input = evento.target;
    const teclaPresionada = evento.key;
    const esNumero = teclaPresionada >= '0' && teclaPresionada <= '9';
    const esPunto = teclaPresionada === '.';
    const teclasControl = ['Backspace', 'Delete', 'Tab', 'ArrowLeft', 'ArrowRight', 'Home', 'End'];
    if (esPunto && input.value.includes('.')) {
        evento.preventDefault();
        return;
    }
    if (!esNumero && !esPunto && !teclasControl.includes(teclaPresionada)) {
        evento.preventDefault();
    }
};

const soloLetras = (evento) => {
    const teclaPresionada = evento.key;
    const esValido = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]$/.test(teclaPresionada);
    const teclasControl = ['Backspace', 'Delete', 'Tab', 'ArrowLeft', 'ArrowRight', 'Home', 'End'];
    if (!esValido && !teclasControl.includes(teclaPresionada)) {
        evento.preventDefault();
    }
};

document.addEventListener("DOMContentLoaded", function(){

    const formularios_ajax = document.querySelectorAll(".FormularioAjax");
    formularios_ajax.forEach(form => {
        form.addEventListener("submit", function(e){
            e.preventDefault();
            const submitButton = form.querySelector('button[type="submit"]');

            const ubicacionSelectCat = form.querySelector('#categoria_ubicacion');
            const inputUbicacionNuevaCat = form.querySelector('#input_ubicacion_nueva');
            if (ubicacionSelectCat && inputUbicacionNuevaCat) {
                if (ubicacionSelectCat.value === "crear_nueva" && inputUbicacionNuevaCat.value.trim() === "") {
                    alert("Por favor, escriba una nueva ubicación antes de guardar.");
                    inputUbicacionNuevaCat.focus();
                    return;
                }
            }

            let originalButtonText = 'Guardar';
            if (submitButton) {
                originalButtonText = submitButton.textContent;
                submitButton.disabled = true;
                submitButton.textContent = 'Guardando...';
            }

            const data = new FormData(this);
            const action = this.getAttribute("action");
            const method = this.getAttribute("method");

            fetch(action, { method: method, body: data })
                .then(res => {
                    if (!res.ok) throw new Error('Respuesta del servidor no fue OK: ' + res.status);
                    return res.json();
                })
                .then(respuesta => {
                    if (respuesta.success) {
                        showNotification(respuesta.message, 'success');
                        if (respuesta.redirect) {
                            setTimeout(() => { window.location.href = respuesta.redirect; }, 1500);
                        }
                    } else {
                        showNotification(respuesta.message, 'error');
                    }
                })
                .catch(err => {
                    console.error("Error AJAX:", err);
                    showNotification('Ocurrió un error de comunicación con el servidor.', 'error');
                })
                .finally(() => {
                    if (submitButton) {
                        submitButton.disabled = false;
                        submitButton.textContent = originalButtonText;
                    }
                });
        });
    });

    const fileInputTrigger = document.getElementById('fileInputTrigger');
    const masterFileInput = document.getElementById('fileInputMaster');
    const previewContainer = document.getElementById('imagePreviewContainer') || document.getElementById('newImagePreviewContainer');
    const existingImageContainer = document.getElementById('existingImageContainer');
    const fileNameSpan = document.getElementById('fileName');
    const selectAlmacen = document.getElementById('select_almacen');
    const mainImage = document.getElementById("mainImage");
    const checkboxPaquete = document.getElementById("checkbox_producto");
    const inputPaquete = document.getElementById("input_paquete");
    const inputCodigo = document.querySelector('input[name="producto_codigo"]');
    const inputNombre = document.querySelector('input[name="producto_nombre"]');
    const inputPrecio = document.querySelector('input[name="producto_precio"]');
    const inputStock = document.querySelector('input[name="producto_stock"]');
    const ubicacionSelect = document.getElementById('categoria_ubicacion');
    const inputUbicacionNueva = document.getElementById('input_ubicacion_nueva');
    const inputCategoriaNombre = document.getElementById('categoria_nombre');
    const modalEliminar = document.getElementById("modalEliminar");

    if (fileInputTrigger && masterFileInput && (previewContainer || document.getElementById('newImagePreviewContainer')) && fileNameSpan) {
        const fileStore = new DataTransfer();

        fileInputTrigger.addEventListener('change', () => {
            const file = fileInputTrigger.files[0];
            if (file) {
                const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
                if (!allowedTypes.includes(file.type)) { alert(`El archivo "${file.name}" tiene un formato no permitido.`); fileInputTrigger.value = ''; return; }
                if (file.size > 3 * 1024 * 1024) { alert(`El archivo "${file.name}" supera el límite de 3MB.`); fileInputTrigger.value = ''; return; }
                fileStore.items.add(file);
                updateMasterInputAndPreview();
                createThumbnail(file);
            }
            fileInputTrigger.value = '';
        });

        function createThumbnail(file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const previewWrapper = document.createElement('div');
                previewWrapper.style.position = 'relative';
                const img = document.createElement('img');
                img.src = e.target.result;
                img.style.cssText = 'width: 128px; height: 128px; object-fit: cover; border-radius: 8px;';
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'delete is-small';
                deleteBtn.style.cssText = 'position: absolute; top: 5px; right: 5px;';
                deleteBtn.addEventListener('click', () => removeFile(file, previewWrapper));
                previewWrapper.appendChild(img);
                previewWrapper.appendChild(deleteBtn);
                const targetPreviewContainer = document.getElementById('newImagePreviewContainer') || previewContainer;
                if(targetPreviewContainer) targetPreviewContainer.appendChild(previewWrapper);
            };
            reader.readAsDataURL(file);
        }

        function removeFile(fileToRemove, previewWrapper) {
            const files = Array.from(fileStore.files);
            let indexToRemove = -1;
            for (let i = 0; i < files.length; i++) {
                if (files[i].name === fileToRemove.name && files[i].size === fileToRemove.size) { indexToRemove = i; break; }
            }
            if (indexToRemove !== -1) fileStore.items.remove(indexToRemove);
            updateMasterInputAndPreview();
             const targetPreviewContainer = document.getElementById('newImagePreviewContainer') || previewContainer;
             if(targetPreviewContainer && previewWrapper.parentNode === targetPreviewContainer) {
                targetPreviewContainer.removeChild(previewWrapper);
             }
        }

        function updateMasterInputAndPreview() {
            if(masterFileInput && fileNameSpan){
                masterFileInput.files = fileStore.files;
                const fileCount = fileStore.files.length;
                fileNameSpan.textContent = fileCount > 0 ? `${fileCount} archivo(s) agregado(s)` : 'Seleccione una o más imágenes';
            }
        }

        const formWithImages = fileInputTrigger.closest('form');
        if (formWithImages) {
            formWithImages.addEventListener("reset", () => {
                const newPreviewCont = document.getElementById('newImagePreviewContainer');
                if (newPreviewCont) newPreviewCont.innerHTML = '';
                fileStore.clearData();
                 if (fileNameSpan) updateMasterInputAndPreview();
                 if(existingImageContainer){
                     existingImageContainer.querySelectorAll('.image-preview-wrapper').forEach(w => w.style.display = 'block');
                     formWithImages.querySelectorAll('input[name="imagenes_a_eliminar[]"]').forEach(inp => inp.remove());
                 }
            });
        }
    }

    if (existingImageContainer) {
        const deleteButtons = existingImageContainer.querySelectorAll('.delete-existing-img');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const wrapper = this.closest('.image-preview-wrapper');
                if (!wrapper) return;
                const imageId = wrapper.getAttribute('data-id');
                if (!imageId) return;
                wrapper.style.display = 'none';
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.name = 'imagenes_a_eliminar[]';
                hiddenInput.value = imageId;
                const form = wrapper.closest('form');
                if (form) {
                    form.appendChild(hiddenInput);
                } else {
                    console.error("Form not found for hidden input.");
                }
            });
        });
    }

    if (selectAlmacen) {
        const selectEstante = document.getElementById('select_estante');
        const divAlmacenNuevo = document.getElementById('div_almacen_nuevo');
        const divEstanteNuevo = document.getElementById('div_estante_nuevo');
        const currentEstanteId = selectEstante ? selectEstante.value : null;

        function fillEstantes(almacenId, preselectId = null) {
            if(!selectEstante) return;
            selectEstante.innerHTML = '<option value="">Cargando...</option>';
            selectEstante.disabled = true;
            fetch(`./php/ubicaciones_ajax.php?almacen_id=${almacenId}`)
                .then(res => {
                    if (!res.ok) throw new Error(`Error del servidor: ${res.status}`);
                    return res.json();
                })
                .then(data => {
                    let options = '<option value="">Seleccione un estante</option>';
                    if (data.length > 0) {
                        data.forEach(item => {
                            const selected = (preselectId && item.estante_id == preselectId) ? 'selected' : '';
                            options += `<option value="${item.estante_id}" ${selected}>${item.nombre}</option>`;
                        });
                    }
                    options += '<option value="crear_nuevo">-- Crear Nuevo Estante --</option>';
                    selectEstante.innerHTML = options;
                    selectEstante.disabled = false;
                })
                .catch(error => {
                    console.error('Error al cargar los estantes:', error);
                    selectEstante.innerHTML = '<option value="">Error al cargar</option>';
                    selectEstante.disabled = true;
                });
        }

        selectAlmacen.addEventListener('change', () => {
            const almacenId = selectAlmacen.value;
            if (divAlmacenNuevo) divAlmacenNuevo.style.display = 'none';
            if (divEstanteNuevo) divEstanteNuevo.style.display = 'none';
            if (selectEstante) selectEstante.disabled = true;

            if (almacenId === 'crear_nuevo') {
                if (divAlmacenNuevo) divAlmacenNuevo.style.display = 'block';
                if (selectEstante) {
                    selectEstante.innerHTML = '<option value="crear_nuevo" selected>-- Crear Nuevo Estante --</option>';
                    selectEstante.disabled = false;
                }
                if (divEstanteNuevo) divEstanteNuevo.style.display = 'block';
            } else if (almacenId) {
                fillEstantes(almacenId);
            } else {
                if (selectEstante) selectEstante.innerHTML = '<option value="">Seleccione un almacén primero</option>';
            }
        });

        if (selectEstante) {
            selectEstante.addEventListener('change', () => {
                if (divEstanteNuevo) divEstanteNuevo.style.display = selectEstante.value === 'crear_nuevo' ? 'block' : 'none';
            });
        }

        const initialAlmacenId = selectAlmacen.value;
        if (initialAlmacenId && initialAlmacenId !== 'crear_nuevo') {
            fillEstantes(initialAlmacenId, currentEstanteId);
        } else if (!initialAlmacenId) {
             if (selectEstante) selectEstante.disabled = true;
        }
    }

    if (mainImage) {
        const zoomImage = document.getElementById("zoomImage");
        const thumbnails = document.querySelectorAll(".thumbnail");
        const imageContainer = document.getElementById("imageContainer");
        const zoomView = document.getElementById("zoomView");
        function setActiveThumbnail(activeThumb) { thumbnails.forEach(thumb => thumb.classList.remove('is-active')); if (activeThumb) activeThumb.classList.add('is-active'); }
        thumbnails.forEach(thumb => { thumb.addEventListener("click", () => { const newImageSrc = thumb.src; mainImage.src = newImageSrc; if(zoomImage) zoomImage.src = newImageSrc; setActiveThumbnail(thumb); }); });
        if (thumbnails.length > 0) setActiveThumbnail(thumbnails[0]);
        if (imageContainer && zoomView && zoomImage) {
            imageContainer.addEventListener("mouseenter", () => { zoomView.style.display = "block"; });
            imageContainer.addEventListener("mouseleave", () => { zoomView.style.display = "none"; });
            imageContainer.addEventListener("mousemove", (e) => { const rect = imageContainer.getBoundingClientRect(); const x = e.clientX - rect.left; const y = e.clientY - rect.top; const xPercent = x / rect.width; const yPercent = y / rect.height; zoomImage.style.left = `-${xPercent * (zoomImage.offsetWidth - zoomView.offsetWidth)}px`; zoomImage.style.top = `-${yPercent * (zoomImage.offsetHeight - zoomView.offsetHeight)}px`; });
        }
    }

    if(checkboxPaquete && inputPaquete){
        checkboxPaquete.addEventListener('change', function() { if (this.checked) { inputPaquete.disabled = false; inputPaquete.focus(); } else { inputPaquete.disabled = true; inputPaquete.value = ''; } });
        inputPaquete.addEventListener('keydown', soloNumeros);
    }
    if (inputCodigo) inputCodigo.addEventListener('keydown', soloNumeros);
    if (inputNombre) inputNombre.addEventListener('keydown', soloLetras);
    if (inputPrecio) inputPrecio.addEventListener('keydown', soloPrecio);
    if (inputStock) inputStock.addEventListener('keydown', soloNumeros);

    if (ubicacionSelect && inputUbicacionNueva) {
        function actualizarEstadoUbicacion() {
            if (ubicacionSelect.value === 'crear_nueva') {
                inputUbicacionNueva.disabled = false;
                inputUbicacionNueva.placeholder = "Escriba el nombre y presione Guardar";
                inputUbicacionNueva.focus();
            } else {
                inputUbicacionNueva.disabled = true;
                inputUbicacionNueva.placeholder = "Seleccione 'Agregar nueva ubicación' para habilitar";
                inputUbicacionNueva.value = '';
            }
        }
        ubicacionSelect.addEventListener('change', actualizarEstadoUbicacion);
        actualizarEstadoUbicacion();
        inputUbicacionNueva.addEventListener('input', function() { this.value = this.value.toUpperCase(); });
    }
    
    if (inputCategoriaNombre) {
        inputCategoriaNombre.addEventListener('input', function() { this.value = this.value.toUpperCase(); });
    }

    if (modalEliminar) {
        const btnCerrar = document.getElementById("cerrarModal");
        const btnCancelar = document.getElementById("cancelarEliminar");
        const btnConfirmar = document.getElementById("btnConfirmarEliminar");
        const modalBackground = modalEliminar.querySelector(".modal-background");

        document.querySelectorAll(".js-delete-button").forEach(boton => {
            boton.addEventListener("click", (e) => {
                e.preventDefault();
                let id = boton.getAttribute("data-id");
                // Determina si es para producto o categoría basado en la URL actual o algún otro indicador
                let vistaActual = window.location.search.includes('category_list') ? 'category_list' : 'product_list';
                let deleteUrl = vistaActual === 'category_list' ? 
                                `./php/categoria_eliminar.php?category_id_del=${id}` : 
                                `./php/producto_eliminar.php?product_id_del=${id}`;
                
                if (btnConfirmar) btnConfirmar.href = deleteUrl;
                modalEliminar.classList.add("is-active");
            });
        });

        const closeModal = () => modalEliminar.classList.remove("is-active");
        if(btnCerrar) btnCerrar.addEventListener("click", closeModal);
        if(btnCancelar) btnCancelar.addEventListener("click", closeModal);
        if(modalBackground) modalBackground.addEventListener("click", closeModal);
    }

    const urlParams = new URLSearchParams(window.location.search);
    const deletedStatus = urlParams.get('deleted'); // Para productos
    const catDeletedStatus = urlParams.get('cat_deleted'); // Para categorías

    if (deletedStatus) {
        let message = '';
        let type = 'error';
        if (deletedStatus === 'ok') { message = 'Producto eliminado exitosamente.'; type = 'success'; }
        else if (deletedStatus === 'error') { message = 'Error: No se pudo eliminar el producto.'; }
        else if (deletedStatus === 'notfound') { message = 'Error: El producto no fue encontrado.'; }
        if (message) { showNotification(message, type); }
        const newUrl = window.location.pathname + window.location.search.replace(/&?deleted=[^&]*/, '');
        window.history.replaceState({}, document.title, newUrl);
    } else if (catDeletedStatus) {
         let message = '';
        let type = 'error';
        switch (catDeletedStatus) {
            case 'ok': message = 'Categoría eliminada exitosamente.'; type = 'success'; break;
            case 'error': message = 'Error: No se pudo eliminar la categoría.'; break;
            case 'has_products': message = 'Error: No se puede eliminar la categoría porque tiene productos asociados.'; break;
            case 'notfound': message = 'Error: La categoría no fue encontrada.'; break;
        }
        if (message) { showNotification(message, type); }
        const newUrlCat = window.location.pathname + window.location.search.replace(/&?cat_deleted=[^&]*/, '');
        window.history.replaceState({}, document.title, newUrlCat);
    }

}); 