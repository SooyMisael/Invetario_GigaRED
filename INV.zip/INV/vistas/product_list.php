<div class="container is-fluid mb-6">
    <h1 class="title">Productos</h1>
    <h2 class="subtitle">Lista de productos</h2>
</div>

<div class="container pb-6 pt-6">
    <div class="mb-4">
        <a href="./php/exportar_pdf.php" target="_blank" class="button is-link is-light">
            <i class="fas fa-file-pdf mr-2"></i>
            <span>Exportar PDF</span>
        </a>
    </div>
    <?php
        require_once "./php/main.php";

        if(!isset($_GET['page'])){ $pagina=1; }
        else{ $pagina=(int) $_GET['page']; if($pagina<=1){ $pagina=1; } }

        $categoria_id = (isset($_GET['category_id'])) ? $_GET['category_id'] : 0;
        $pagina=limpiar_cadena($pagina);
        $url="index.php?vista=product_list&page=";
        $registros=10;
        $busqueda="";

        require_once "./php/producto_lista.php";
    ?>
    <div class="modal" id="modalEliminar">
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
                <p class="modal-card-title">Confirmar eliminación</p>
                <button class="delete" aria-label="close" id="cerrarModal"></button>
            </header>
            <section class="modal-card-body">
                <p>¿Estás seguro de que deseas eliminar el producto: <strong id="nombreProductoEliminar"></strong>? Esta acción no se puede deshacer.</p>
            </section>
            <footer class="modal-card-foot">
                <button class="button" id="cancelarEliminar">Cancelar</button>
                <a href="#" class="button is-danger" id="btnConfirmarEliminar">Eliminar</a>
            </footer>
        </div>
    <
<style>
    
    .image.is-64x64 img {
        width: 100%;
        height: 100%;
        object-fit: contain; 
        border-radius: 0px;  
        background-color: #ffffff; 
    }
    .image-zoom-container {
        position: relative; 
        display: inline-block;
        cursor: pointer;
        width: 64px; 
        height: 64px;
    }

    .image-zoom-container .image.is-64x64 {
        position: relative;
        z-index: 1; 
    }

    .zoomed-image {
        display: none; 
        position: absolute;
        top: 0; 
        left: 100%;
        margin-left: 20px; 
        width: 350px;  
        height: auto;
        max-width: none; 
        max-height: 80vh; 
        border: 3px solid white;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        z-index: 1000; 
    }
    .image-zoom-container:hover .zoomed-image {
        display: block; 
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {

    const modal = document.getElementById('modalEliminar');
    const botonCerrar = document.getElementById('cerrarModal');
    const botonCancelar = document.getElementById('cancelarEliminar');
    const fondoModal = document.querySelector('.modal-background');
    

    const textoNombreProducto = document.getElementById('nombreProductoEliminar'); 
    const botonConfirmarEliminar = document.getElementById('btnConfirmarEliminar'); 
    const todosLosBotonesEliminar = document.querySelectorAll('.js-delete-button'); 


    const cerrarModal = () => {
        modal.classList.remove('is-active');
    }
    botonCerrar.addEventListener('click', cerrarModal);
    botonCancelar.addEventListener('click', cerrarModal);
    fondoModal.addEventListener('click', cerrarModal);

    todosLosBotonesEliminar.forEach(boton => {
        boton.addEventListener('click', (e) => {
            e.preventDefault(); 
            
  
            const id = boton.getAttribute('data-id');
            const nombre = boton.getAttribute('data-nombre');

           
            textoNombreProducto.textContent = nombre; 
            
       
            botonConfirmarEliminar.href = `./php/producto_eliminar.php?product_id_del=${id}`;
            
            modal.classList.add('is-active');
        });
    });

});
</script>
