<?php
    // 1. Iniciar la sesión ANTES que cualquier HTML
    require_once "./inc/session_start.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include "./inc/head.php"; ?>
    </head>
    <body>
        <div id="notification-container"></div>

        <?php
            // 2. Lógica de vistas y sesión
            $vista = $_GET['vista'] ?? "login"; // Por defecto, la vista es "login"

            if (!isset($_SESSION['id']) || empty($_SESSION['id'])) {
                // --- USUARIO NO LOGUEADO ---
                // Si el usuario NO ha iniciado sesión, solo puede ver "login" y "register"
                if ($vista != "login" && $vista != "register") {
                    $vista = "login"; // Si intenta ir a 'home' o 'product_list', lo mandamos a 'login'
                }
            } else {
                // --- USUARIO SÍ LOGUEADO ---
                // Si el usuario YA inició sesión, no debe ver "login" ni "register"
                if ($vista == "login" || $vista == "register") {
                    $vista = "home"; // Si intenta ir a 'login', lo mandamos a 'home'
                }
            }

            // 3. Cargar la vista correspondiente
            if (is_file("./vistas/".$vista.".php")) {

                // Solo muestra el navbar si la vista NO es login o register
                if ($vista != "login" && $vista != "register") {
                    include "./inc/navbar.php";
                    echo '<div class="main-content">'; // Contenedor principal con margen
                } else {
                    echo '<div class="main-content is-full-width">'; // Contenedor para login/register
                }
                
                include "./vistas/".$vista.".php"; // Carga la vista
                echo '</div>'; // Cierra el div de contenido

                include "./inc/script.php";

            } else {
                include "./vistas/404.php";
            }
        ?>
    </body>
</html>