<div class="container is-fluid mb-6">
	<h1 class="title">Categorías</h1>
	<h2 class="subtitle">Nueva categoría</h2>
</div>

<div class="container pb-6 pt-6">

	<div class="form-rest mb-6 mt-6"></div>

	<form action="./php/categoria_guardar.php" method="POST" class="FormularioAjax" autocomplete="off" >
		<div class="columns">
		  	<div class="column">
		    	<div class="control">
					<label>Nombre</label>
				  	<input class="input" id="categoria_nombre" type="text" name="categoria_nombre" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]{2,50}" maxlength="50" required >

					<div class="select is-fullwidth">
					  <select name="categoria_ubicacion" required >
					    <option value="BODEGA">BODEGA</option>
					    <option value="CASA">CASA</option>
					  </select>
					</div>
				</div>
		  	</div>
		</div>
		<p class="has-text-centered">
			<button type="submit" class="button is-info">Guardar</button>
		</p>
	</form>
</div>

<script>
    const inputNombre = document.querySelector('#categoria_nombre');
	const inputCategoria = document.querySelector('#categoria_ubicacion');

    inputNombre.addEventListener('input', function() {
        this.value = this.value.toUpperCase();
    });

	inputCategoria.addEventListener('input', function() {
        this.value = this.value.toUpperCase();
    });
</script>