<div class="container is-fluid mb-6">
	<h1 class="title">Categorías</h1>
	<h2 class="subtitle">Nueva categoría</h2>
</div>

<div class="container pb-6 pt-6">
	<?php
		require_once "./php/main.php";
	?>

	<div class="form-rest mb-6 mt-6"></div>

	<form action="./php/categoria_guardar.php" method="POST" class="FormularioAjax" autocomplete="off">

		<!-- CONTENEDOR 1: Nombre -->
		<div class="columns">
		  	<div class="column">
		    	<div class="control">
					<label>Nombre de la Categoría</label>
				  	<input class="input" id="categoria_nombre" type="text" name="categoria_nombre" 
						pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]{2,50}" maxlength="50" required >
				</div>
		  	</div>
		</div>

		<!-- CONTENEDOR 2: Seleccionar ubicación existente -->
		<div class="columns">
			<div class="column">
				<label>Seleccionar Ubicación Existente</label>
				<div class="control">
					<div class="select is-fullwidth">
						<select name="categoria_ubicacion" id="categoria_ubicacion" required>
							<option value="" selected>Seleccione una opción (si existe)</option>
							<?php
								// Mostrar ubicaciones distintas que ya existen en la tabla categoría
								$ubicaciones = conexion();
								$query = $ubicaciones->query("SELECT DISTINCT categoria_ubicacion FROM categoria WHERE categoria_ubicacion IS NOT NULL AND categoria_ubicacion <> '' ORDER BY categoria_ubicacion ASC");

								if($query->rowCount() > 0){
									foreach($query as $row){
										echo '<option value="'.$row['categoria_ubicacion'].'">'.$row['categoria_ubicacion'].'</option>';
									}
								}
								$ubicaciones = null;
							?>
							<option value="crear_nueva">Agregar nueva ubicación</option>
						</select>
					</div>
				</div>
			</div>

			<!-- CONTENEDOR 3: Crear nueva ubicación -->
			<div class="column" id="contenedor_ubicacion_nueva">
				<label>O Crear una Nueva Ubicación</label>
				<div class="control">
					<input class="input" type="text" name="input_ubicacion_nueva" id="input_ubicacion_nueva"
						pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]{3,100}" maxlength="100"
						placeholder="Escriba aquí solo si no está en la lista de arriba" disabled>
				</div>
			</div>
		</div>

		<p class="has-text-centered mt-5">
			<button type="submit" class="button is-info">Guardar</button>
			<button type="reset" class="button is-light">Limpiar</button>
		</p>
	</form>
</div>
