<div class="container is-fluid mb-6">
    <h1 class="title">Productos</h1>
    <h2 class="subtitle">Actualizar producto</h2>
</div>

<div class="container pb-6 pt-6">
    <?php
        require_once "./php/main.php";

        $id = (isset($_GET['product_id_up'])) ? $_GET['product_id_up'] : 0;
        $id=limpiar_cadena($id);

        $conexion=conexion();

        /*== Verificando producto y obteniendo su ubicación actual ==*/
        $check_producto=$conexion->prepare("
            SELECT producto.*, estantes.almacen_id
            FROM producto
            LEFT JOIN estantes ON producto.estante_id = estantes.estante_id
            WHERE producto.producto_id = :id
        ");
        $check_producto->execute([':id' => $id]);

        if($check_producto->rowCount()>0){
            $datos=$check_producto->fetch(PDO::FETCH_ASSOC);

            // Guardamos los IDs de ubicación actuales para preselección
            $current_estante_id = $datos['estante_id'];
            $current_almacen_id = $datos['almacen_id'];

            // Obtener las imágenes existentes del producto
            $check_imagenes = $conexion->prepare("SELECT imagen_id, nombre_archivo FROM producto_imagenes WHERE producto_id = :id ORDER BY orden ASC, imagen_id ASC");
            $check_imagenes->execute([':id' => $id]);
            $imagenes_existentes = $check_imagenes->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="form-rest mb-6 mt-6"></div>

    <h2 class="title has-text-centered"><?php echo htmlspecialchars($datos['producto_nombre']); ?></h2>

    <form action="./php/producto_actualizar.php" method="POST" class="FormularioAjax" autocomplete="off" enctype="multipart/form-data">

        <input type="hidden" name="producto_id" value="<?php echo $datos['producto_id']; ?>" required >

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label>Código de barra</label>
                    <input class="input" type="text" name="producto_codigo" pattern="[a-zA-Z0-9- ]{1,70}" maxlength="70" required value="<?php echo htmlspecialchars($datos['producto_codigo']); ?>" >
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label>Nombre</label>
                    <input class="input" type="text" name="producto_nombre" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ().,$#\-\/ ]{1,70}" maxlength="70" required value="<?php echo htmlspecialchars($datos['producto_nombre']); ?>" >
                </div>
            </div>
        </div>
        <div class="columns">
            <div class="column">
                <div class="control">
                    <label>Precio</label>
                    <input class="input" type="text" name="producto_precio" pattern="[0-9.]{1,25}" maxlength="25" required value="<?php echo htmlspecialchars($datos['producto_precio']); ?>" >
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label>Stock</label>
                    <input class="input" type="text" name="producto_stock" pattern="[0-9]{1,25}" maxlength="25" required value="<?php echo htmlspecialchars($datos['producto_stock']); ?>" >
                </div>
            </div>
            <div class="column">
                <label>Categoría</label><br>
                <div class="control">
                    <div class="select is-fullwidth">
                        <select name="producto_categoria" >
                            <?php
                                $categorias=$conexion->query("SELECT * FROM categoria");
                                if($categorias->rowCount()>0){
                                    $categorias=$categorias->fetchAll();
                                    foreach($categorias as $row){
                                        $selected = ($datos['categoria_id']==$row['categoria_id']) ? 'selected' : '';
                                        echo '<option value="'.$row['categoria_id'].'" '.$selected.' >'.$row['categoria_nombre'].'</option>';
                                    }
                                }
                            ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label>Proveedor</label>
                    <input class="input" type="text" name="producto_proveedor" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ().,$#\-\/ ]{1,70}" maxlength="70" required value="<?php echo htmlspecialchars($datos['producto_proveedor']); ?>">
                </div>
            </div>
            <div class="column">
                <label>Almacén</label>
                <div class="control">
                    <div class="select is-fullwidth">
                        <select name="almacen_id" id="select_almacen">
                            <option value="">Seleccione un almacén</option>
                            <?php
                                $almacenes = $conexion->query("SELECT * FROM almacenes ORDER BY nombre");
                                foreach ($almacenes as $almacen) {
                                    $selected = ($current_almacen_id == $almacen['almacen_id']) ? 'selected' : '';
                                    echo '<option value="'.$almacen['almacen_id'].'" '.$selected.'>'.htmlspecialchars($almacen['nombre']).'</option>';
                                }
                            ?>
                            <option value="crear_nuevo">-- Crear Nuevo Almacén --</option>
                        </select>
                    </div>
                </div>
                <div class="control mt-2" id="div_almacen_nuevo" style="display: none;">
                    <input class="input" type="text" name="almacen_nuevo" placeholder="Nombre del nuevo almacén">
                </div>
            </div>

            <div class="column">
                <label>Estante / Rack</label>
                <div class="control">
                    <div class="select is-fullwidth">
                        <select name="estante_id" id="select_estante">
                            <option value="">Seleccione un almacén primero</option>
                            <?php
                                if($current_almacen_id) {
                                    $estantes = $conexion->prepare("SELECT estante_id, nombre FROM estantes WHERE almacen_id = :aid ORDER BY nombre");
                                    $estantes->execute([':aid' => $current_almacen_id]);
                                    $estantes_disponibles = $estantes->fetchAll(PDO::FETCH_ASSOC);

                                    if(count($estantes_disponibles) > 0) {
                                        foreach($estantes_disponibles as $estante) {
                                            $selected = ($current_estante_id == $estante['estante_id']) ? 'selected' : '';
                                            echo '<option value="'.$estante['estante_id'].'" '.$selected.'>'.htmlspecialchars($estante['nombre']).'</option>';
                                        }
                                    }
                                    echo '<option value="crear_nuevo">-- Crear Nuevo Estante --</option>';
                                } else {
                                     echo '<option value="crear_nuevo">-- Crear Nuevo Estante --</option>';
                                }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="control mt-2" id="div_estante_nuevo" style="display: none;">
                    <input class="input" type="text" name="estante_nuevo" placeholder="Nombre del nuevo estante">
                </div>
            </div>
        </div>


        <div class="columns">
            <div class="column">
                <div class="control">
                    <label>Detalle o descripción</label>
                    <textarea class="textarea" name="producto_detalle" maxlength="1000" required><?php echo htmlspecialchars($datos['producto_detalle']); ?></textarea>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <label class="label">Gestionar Fotos del Producto</label>

                <p class="mb-2">Imágenes actuales:</p>
                <div id="existingImageContainer" style="display: flex; flex-wrap: wrap; gap: 15px;" class="mb-4">
                    <?php foreach ($imagenes_existentes as $img) { ?>
                        <div class="image-preview-wrapper" style="position: relative;" data-id="<?php echo $img['imagen_id']; ?>">
                            <img src="./img/producto/<?php echo htmlspecialchars($img['nombre_archivo']); ?>" style="width: 128px; height: 128px; object-fit: cover; border-radius: 8px;">
                            <button type="button" class="delete is-small delete-existing-img" style="position: absolute; top: 5px; right: 5px;"></button>
                        </div>
                    <?php } ?>
                </div>

                <p class="mb-2">Agregar nuevas imágenes:</p>
                <input type="file" name="producto_fotos_nuevas[]" id="fileInputMaster" multiple style="display: none;">
                <div class="file is-small has-name mb-4">
                    <label class="file-label">
                        <input class="file-input" type="file" id="fileInputTrigger" accept=".jpg, .png, .jpeg">
                        <span class="file-cta">
                            <span class="icon is-small"><i class="fas fa-upload"></i></span>
                            <span class="file-label">Agregar Imagen…</span>
                        </span>
                        <span id="fileName" class="file-name">Seleccione una o más imágenes</span>
                    </label>
                </div>

                <div id="newImagePreviewContainer" style="display: flex; flex-wrap: wrap; gap: 15px;"></div>
            </div>
        </div>

        <p class="has-text-centered">
            <button type="submit" class="button is-success">Actualizar</button>
        </p>
    </form>
    <?php
        } else {
            include "./inc/error_alert.php";
        }
        $check_producto=null;
        $conexion=null;
    ?>
</div>