<div class="container is-fluid mb-6">
    <h1 class="title"></h1>
    <h2 class="subtitle"></h2>
</div>

<div class="container pb-6 pt-6">

    <div class="form-rest mb-6 mt-6"></div>

    <div class="login-form-container">
        
        <div class="has-text-centered mb-4">
            <span class="icon is-large has-text-info">
                <i class="fas fa-user-plus fa-3x"></i>
            </span>
        </div>
        
        <h2 class="title is-4 has-text-centered has-text-dark mb-2">
            Crear Nueva Cuenta
        </h2>
        <p class="subtitle is-6 has-text-centered has-text-grey mb-5">
            Completa tus datos para registrarte.
        </p>

        <form action="./php/registro_guardar.php" method="POST" class="FormularioAjax" autocomplete="off">

            <div class="field">
                <div class="control has-icons-left">
                    <input class="input" type="text" name="usuario_nombre" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,100}" maxlength="100" placeholder="Nombre Completo" required >
                    <span class="icon is-small is-left">
                        <i class="fas fa-user"></i>
                    </span>
                </div>
            </div>

            <div class="field">
                <div class="control has-icons-left">
                    <input class="input" type="email" name="usuario_email" maxlength="100" placeholder="Email" required >
                    <span class="icon is-small is-left">
                        <i class="fas fa-envelope"></i>
                    </span>
                </div>
            </div>

            <div class="field">
                <div class="control has-icons-left">
                    <input class="input" type="password" name="usuario_clave_1" id="reg_clave_1" pattern="[a-zA-Z0-9$@.-]{8,100}" maxlength="100" placeholder="Contraseña" required >
                    <span class="icon is-small is-left">
                        <i class="fas fa-lock"></i>
                    </span>
                </div>
            </div>

            <div class="field">
                <div class="control has-icons-left has-icons-right">
                    <input class="input" type="password" name="usuario_clave_2" id="reg_clave_2" pattern="[a-zA-Z0-9$@.-]{8,100}" maxlength="100" placeholder="Confirmar Contraseña" required >
                    <span class="icon is-small is-left">
                        <i class="fas fa-lock"></i>
                    </span>
                    <span class="icon is-small is-right" id="reg_clave_icon">
                        </span>
                </div>
            </div>
            
            <p class="has-text-centered mt-5">
                <button type="submit" class="button is-info is-fullwidth has-text-weight-bold">REGISTRAR</button>
            </p>

            <p class="has-text-centered has-text-grey-light mt-4">
                ¿Ya tienes una cuenta? <a href="index.php?vista=login">Inicia sesión aquí</a>
            </p>
        </form>
    </div>
</div>