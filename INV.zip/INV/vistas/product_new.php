<div class="container is-fluid mb-6">
    <h1 class="title">Productos</h1>
    <h2 class="subtitle">Nuevo producto</h2>
</div>

<div class="container pb-6 pt-6">
    <?php
        require_once "./php/main.php";
    ?>

    <div class="form-rest mb-6 mt-6"></div>

    <form action="./php/producto_guardar.php" method="POST" class="FormularioAjax" autocomplete="off" enctype="multipart/form-data" >
        <div class="columns">
            <div class="column">
                <div class="control">
                    <label>Código</label>
                    <span class="tooltip-icono">?
                        <span class="tooltip-texto">
                            El código debe contener solo números...
                        </span>
                    </span>
                    <input class="input" type="text" name="producto_codigo" pattern="[0-9]{1,70}" placeholder="Solo números, máximo 70 dígitos." maxlength="70" required >
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label>Nombre</label>
                    <span class="tooltip-icono">?
                        <span class="tooltip-texto">
                            El nombre del producto puede incluir letras...
                        </span>
                    </span>
                    <input class="input" type="text" name="producto_nombre" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ().,$#\-\/ ]{1,70}" maxlength="70" required >
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <label>Precio de Costo (Proveedor)</label>
                <div class="field has-addons">
                    <div class="control">
                        <span class="select">
                            <select name="producto_costo_moneda">
                                <option value="MXN" selected>MXN</option>
                                <option value="USD">USD</option>
                            </select>
                        </span>
                    </div>
                    <div class="control is-expanded">
                        <input class="input" type="text" name="producto_costo" pattern="[0-9.]{1,25}" placeholder="Cuánto te costó" maxlength="25" required>
                    </div>
                </div>
            </div>
            <div class="column">
                <label>Precio de Venta (Público)</label>
                <div class="field has-addons">
                    <div class="control">
                        <span class="select">
                            <select name="producto_venta_moneda">
                                <option value="MXN" selected>MXN</option>
                                <option value="USD">USD</option>
                            </select>
                        </span>
                    </div>
                    <div class="control is-expanded">
                        <input class="input" type="text" name="producto_venta" pattern="[0-9.]{1,25}" placeholder="Precio al público" maxlength="25" required>
                    </div>
                </div>
            </div>
        </div>
        <div class="columns">
             <div class="column">
                <div class="control">
                    <label>Unidades por paquete</label>
                    <input class="input" type="text" name="producto_paquete" id="input_paquete" pattern="[0-9]{1,25}" placeholder="Ej: 12" disabled>
                </div>
                <div class="control" style="margin-top: 10px;">
                    <label class="checkbox">
                        <input type="checkbox" id="checkbox_producto" name="es_paquete" value="1">
                        ¿Este producto es un paquete?
                    </label>
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label>Cantidad</label>
                    <input class="input" type="text" name="producto_stock" pattern="[0-9]{1,25}" placeholder="Solo números, máximo 25 dígitos." maxlength="25" required >
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label>Proveedor</label>
                    <input class="input" type="text" name="producto_proveedor" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ().,$#\-\/ ]{1,70}" maxlength="70" required >
                </div>
            </div>
        </div>
        <div class="columns">
            <div class="column">
                <label>Categoría</label><br>
                <div class="select is-fullwidth">
                    <select name="producto_categoria" >
                        <option value="" selected="" >Seleccione una opción</option>
                        <?php
                            $categorias=conexion();
                            $categorias=$categorias->query("SELECT * FROM categoria");
                            if($categorias->rowCount()>0){
                                $categorias=$categorias->fetchAll();
                                foreach($categorias as $row){
                                    echo '<option value="'.$row['categoria_id'].'" >'.$row['categoria_nombre'].'</option>';
                                }
                            }
                            $categorias=null;
                        ?>
                    </select>
                </div>
            </div>
            <div class="column">
                <label>Condición</label>
                <div class="control">
                    <div class="select is-fullwidth">
                        <select name="producto_condicion" >
                            <option value="" selected="" >Seleccione una opción</option>
                            <option value="Nuevo">Nuevo</option>
                            <option value="Seminuevo" >Seminuevo</option>
                            <option value="Usado" >Usado</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <label>Estante / Ubicación</label>
                <span class="tooltip-icono">?
                    <span class="tooltip-texto">
                        Seleccione el estante o rack...
                    </span>
                </span>
                <div class="control">
                    <div class="select is-fullwidth">
                        <select name="estante_id" id="select_estante">
                            <option value="" selected>Seleccione un estante</option>
                            <?php
                                $estantes = conexion()->query("SELECT * FROM estantes ORDER BY nombre");
                                foreach ($estantes as $estante) {
                                    echo '<option value="'.$estante['estante_id'].'">'.$estante['nombre'].'</option>';
                                }
                            ?>
                            <option value="crear_nuevo">-- Crear Nuevo Estante --</option>
                        </select>
                    </div>
                </div>
                <div class="control mt-2" id="div_estante_nuevo" style="display: none;">
                    <input class="input" type="text" name="estante_nuevo" placeholder="Nombre del nuevo estante">
                </div>
            </div>
            <div class="column">
            </div>
        </div>


        <div class="columns">
            <div class="column">
                <div class="control">
                    <label>Detalle o descripción</label>
                    <textarea class="textarea" name="producto_detalle" maxlength="1000" placeholder="Escribe una breve descripción del producto" required></textarea>
                </div>
            </div>
        </div>
        
        <div class="columns">
            <div class="column">
                <label>Fotos del producto</label>
                <span class="tooltip-icono">?
                    <span class="tooltip-texto">
                        Puedes subir múltiples imágenes...
                    </span>
                </span>
                
                <input type="file" name="producto_fotos[]" id="fileInputMaster" multiple style="display: none;">

                <div class="file is-small has-name mb-4">
                    <label class="file-label">
                        <input class="file-input" type="file" id="fileInputTrigger" accept=".jpg, .png, .jpeg">
                        <span class="file-cta">
                            <span class="icon is-small">
                                <i class="fas fa-upload"></i>
                            </span>
                            <span class="file-label">Agregar Imagen…</span>
                        </span>
                        <span id="fileName" class="file-name">Seleccione una o más imágenes</span>
                    </label>
                </div>
                
                <div id="imagePreviewContainer" style="display: flex; flex-wrap: wrap; gap: 15px;"></div>
            </div>
        </div>

        <p class="has-text-centered">
            <button type="submit" class="button is-info">Guardar</button>
            <button type="reset" class="button is-light">Limpiar</button>
        </p>
    </form>
</div>

<style>
/* --- Ajustar espacio entre el título y el contenido --- */
.container.is-fluid.mb-6 {
    margin-bottom: 1rem !important;
    margin-top: 1rem !important;
}

/* --- Botón de regresar en la esquina superior derecha --- */
.container.pb-6.pt-6 {
    position: relative;
}

.container.pb-6.pt-6 .btn-back,
.container.pb-6.pt-6 a.button {
    position: absolute;
    top: 10px;
    right: 10px;
    z-index: 10;
    margin: 0;
}

/* --- Reducir espacio extra antes del formulario --- */
.form-rest.mb-6.mt-6 {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
}
</style>