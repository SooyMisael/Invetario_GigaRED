<div class="container is-fluid">
	<h1 class="title">¡Bienvenido!</h1>
</div>