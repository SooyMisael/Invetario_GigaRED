<div class="container is-fluid">
    <h1 class="title">¡Bienvenido!</h1> <br>

    <!-- BUSCADOR DE PRODUCTOS CENTRADO -->
    <div class="columns is-centered mt-4 mb-6">
        <div class="column is-half">
            <?php
                require_once "./php/main.php";
                require_once "./inc/session_start.php";

                if(isset($_POST['modulo_buscador'])){
                    require_once "./php/buscador.php";
                }

                if(!isset($_SESSION['busqueda_producto']) || empty($_SESSION['busqueda_producto'])){
            ?>
            <form action="" method="POST" autocomplete="off">
                <input type="hidden" name="modulo_buscador" value="producto">
                <div class="field has-addons">
                    <div class="control is-expanded">
                        <input class="input" type="text" name="txt_buscador" placeholder="¿Qué estás buscando?" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]{1,30}" maxlength="30">
                    </div>
                    <div class="control">
                        <button class="button is-info" type="submit">Buscar</button>
                    </div>
                </div>
            </form>
            <?php } else { ?>
            <form action="" method="POST" autocomplete="off" class="has-text-centered">
                <input type="hidden" name="modulo_buscador" value="producto">
                <input type="hidden" name="eliminar_buscador" value="producto">
                <p>Estás buscando <strong>“<?php echo $_SESSION['busqueda_producto']; ?>”</strong></p>
                <button type="submit" class="button is-danger mt-2">Eliminar búsqueda</button>
            </form>
            <?php } ?>
        </div>
    </div>


    <!-- BLOQUES DE ACCESO RÁPIDO -->
    <div class="columns is-multiline mt-5">
        <!-- Bloque 1: Agregar nuevo producto -->
        <div class="column is-one-third">
            <a href="index.php?vista=product_new">
                <div class="dashboard-box has-background-primary">
                    <span class="icon is-large">
                        <i class="fas fa-plus fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Agregar nuevo producto</h2>
                </div>
            </a>
        </div>

        <!-- Bloque 2: Generar PDF de productos -->
        <div class="column is-one-third">
            <a href="./php/exportar_pdf.php" target="_blank">
                <div class="dashboard-box has-background-danger">
                    <span class="icon is-large">
                        <i class="fas fa-file-pdf fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Generar PDF de productos</h2>
                </div>
            </a>
        </div>

        <!-- Bloque 3: Últimos movimientos -->
        <div class="column is-one-third">
            <a href="ultimos_movimientos.php">
                <div class="dashboard-box has-background-warning">
                    <span class="icon is-large">
                        <i class="fas fa-history fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Últimos movimientos</h2>
                </div>
            </a>
        </div>

        <!-- Bloque 4: Últimos movimientos -->
        <div class="column is-one-third">
            <a href="ultimos_movimientos.php">
                <div class="dashboard-box has-background-warning">
                    <span class="icon is-large">
                        <i class="fas fa-history fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">boton 4</h2>
                </div>
            </a>
        </div>

        <!-- Bloque 5: Últimos movimientos -->
        <div class="column is-one-third">
            <a href="ultimos_movimientos.php">
                <div class="dashboard-box has-background-warning">
                    <span class="icon is-large">
                        <i class="fas fa-history fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">boton 5</h2>
                </div>
            </a>
        </div>

        <!-- Bloque 6: Últimos movimientos -->
        <div class="column is-one-third">
            <a href="ultimos_movimientos.php">
                <div class="dashboard-box has-background-warning">
                    <span class="icon is-large">
                        <i class="fas fa-history fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">boton 6</h2>
                </div>
            </a>
        </div>		
    
	</div>
</div>

<!-- Estilos personalizados -->
<style>
.dashboard-box {
    color: white; /* Color del texto */
    padding: 40px 20px;
    border-radius: 10px;
    text-align: center;
    transition: transform 0.2s, box-shadow 0.2s;
    cursor: pointer;
}

.dashboard-box:hover {
    transform: translateY(-5px); /* Efecto levitar */
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.18);
}
</style>