<!-- Sidebar -->
<aside class="menu-sidebar">
    <div class="menu-logo">
        <a href="index.php?vista=home">
            <img src="./img/gigared.png" alt="Logo" class="logo-navbar">
        </a>
    </div>

    <p class="menu-label">Categorías</p>
    <ul class="menu-list">
        <li><a href="index.php?vista=category_new"><i class="fa-solid fa-plus"></i> Nueva</a></li>
        <li><a href="index.php?vista=category_list"><i class="fa-solid fa-list"></i> Lista</a></li>
        
    </ul>

    <p class="menu-label">Productos</p>
    <ul class="menu-list">
        <li><a href="index.php?vista=product_new"><i class="fa-solid fa-plus"></i> Nuevo</a></li>
        <li><a href="index.php?vista=product_list"><i class="fa-solid fa-list"></i> Lista</a></li>
        <li><a href="index.php?vista=product_category"><i class="fa-solid fa-tags"></i> Por categoría</a></li>
        <li><a href="index.php?vista=product_search"><i class="fa-solid fa-magnifying-glass"></i> Buscar</a></li>
    </ul>
</aside>

