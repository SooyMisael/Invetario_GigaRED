<?php
require_once "main.php";

header('Content-Type: application/json');

/*== Almacenando id ==*/
$id = limpiar_cadena($_POST['producto_id']);

$pdo = conexion();

/*== Verificando producto ==*/
$check_producto = $pdo->prepare("SELECT * FROM producto WHERE producto_id = :id");
$check_producto->execute([':id' => $id]);

if ($check_producto->rowCount() <= 0) {
    echo json_encode(["success" => false, "message" => "El producto no existe en el sistema"]);
    exit();
}

/*== Almacenando datos del formulario ==*/
$codigo = limpiar_cadena($_POST['producto_codigo']);
$nombre = limpiar_cadena($_POST['producto_nombre']);
$detalle = limpiar_cadena($_POST['producto_detalle']);
$precio = limpiar_cadena($_POST['producto_precio']);
$stock = limpiar_cadena($_POST['producto_stock']);
$categoria = limpiar_cadena($_POST['producto_categoria']);
$proveedor = limpiar_cadena($_POST['producto_proveedor']);

// --- Datos de la nueva ubicación ---
$almacen_id_seleccionado = limpiar_cadena($_POST['almacen_id']);
$almacen_nuevo_nombre = limpiar_cadena($_POST['almacen_nuevo'] ?? '');
$estante_id_seleccionado = limpiar_cadena($_POST['estante_id']);
$estante_nuevo_nombre = limpiar_cadena($_POST['estante_nuevo'] ?? '');
$estante_id_final = null;


/*== Verificando campos obligatorios ==*/
if ($codigo == "" || $nombre == "" || $precio == "" || $stock == "" || $categoria == "" || $detalle == "" || $proveedor == "" || $almacen_id_seleccionado == "") {
    echo json_encode(["success" => false, "message" => "No has llenado todos los campos que son obligatorios"]);
    exit();
}



/*== Lógica para manejar la ubicación (Almacén y Estante) ==*/
$almacen_id_final = $almacen_id_seleccionado;

if ($almacen_id_seleccionado == 'crear_nuevo') {
    if (empty($almacen_nuevo_nombre)) {
        echo json_encode(["success" => false, "message" => "Debes especificar un nombre para el nuevo almacén"]);
        exit();
    }
    // Verificar si ya existe antes de insertar
    $stmt = $pdo->prepare("INSERT INTO almacenes(nombre) VALUES(:nombre)");
    $stmt->execute([':nombre' => $almacen_nuevo_nombre]);
    $almacen_id_final = $pdo->lastInsertId();
}

if ($estante_id_seleccionado == 'crear_nuevo') {
    if (empty($estante_nuevo_nombre)) {
        echo json_encode(["success" => false, "message" => "Debes especificar un nombre para el nuevo estante"]);
        exit();
    }
    if (empty($almacen_id_final) || !is_numeric($almacen_id_final)) { // Asegurar que tengamos un ID numérico de almacén
        echo json_encode(["success" => false, "message" => "Un nuevo estante debe estar asociado a un almacén válido"]);
        exit();
    }
    //Verificar si ya existe antes de insertar
    $stmt = $pdo->prepare("INSERT INTO estantes(nombre, almacen_id) VALUES(:nombre, :almacen_id)");
    $stmt->execute([':nombre' => $estante_nuevo_nombre, ':almacen_id' => $almacen_id_final]);
    $estante_id_final = $pdo->lastInsertId();
} else {
    $estante_id_final = (int)$estante_id_seleccionado;
}

if(empty($estante_id_final) || !is_numeric($estante_id_final)) { // Asegurar que tengamos un ID numérico final
    echo json_encode(["success" => false, "message" => "La ubicación final (estante) no pudo ser determinada o no es válida."]);
    exit();
}


/*== GESTIÓN DE IMÁGENES ==*/
if (isset($_POST['imagenes_a_eliminar']) && is_array($_POST['imagenes_a_eliminar'])) {
    foreach ($_POST['imagenes_a_eliminar'] as $imagen_id) {
        $imagen_id = limpiar_cadena($imagen_id);
        $get_filename = $pdo->prepare("SELECT nombre_archivo FROM producto_imagenes WHERE imagen_id = :id AND producto_id = :pid");
        $get_filename->execute([':id' => $imagen_id, ':pid' => $id]);
        $filename = $get_filename->fetchColumn();
        if ($filename && is_file("../img/producto/" . $filename)) {
            unlink("../img/producto/" . $filename);
        }
        $delete_img = $pdo->prepare("DELETE FROM producto_imagenes WHERE imagen_id = :id AND producto_id = :pid");
        $delete_img->execute([':id' => $imagen_id, ':pid' => $id]);
    }
}
$img_dir = '../img/producto/';
if (isset($_FILES['producto_fotos_nuevas']) && !empty($_FILES['producto_fotos_nuevas']['name'][0])) {
    if (!file_exists($img_dir)) {
        if (!mkdir($img_dir, 0777, true)) { echo json_encode(["success" => false, "message" => "Error al crear directorio"]); exit(); }
    }
    foreach ($_FILES['producto_fotos_nuevas']['name'] as $key => $nombre_foto) {
        if ($_FILES['producto_fotos_nuevas']['error'][$key] === UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['producto_fotos_nuevas']['tmp_name'][$key];
            if (!in_array(mime_content_type($tmp_name), ["image/jpeg", "image/png"])) { echo json_encode(["success" => false, "message" => "'$nombre_foto': formato no permitido."]); exit(); }
            if (($_FILES['producto_fotos_nuevas']['size'][$key] / 1024) > 3072) { echo json_encode(["success" => false, "message" => "'$nombre_foto' supera 3MB."]); exit(); }
            $extension = pathinfo($nombre_foto, PATHINFO_EXTENSION);
            $nombre_archivo_unico = "prod_" . $id . "_" . time() . "_" . $key . "." . $extension;
            if (move_uploaded_file($tmp_name, $img_dir . $nombre_archivo_unico)) {
                $guardar_img = $pdo->prepare("INSERT INTO producto_imagenes(producto_id, nombre_archivo) VALUES(:pid, :nombre)");
                $guardar_img->execute([":pid" => $id, ":nombre" => $nombre_archivo_unico]);
            } else { echo json_encode(["success" => false, "message" => "Error al mover '$nombre_foto'"]); exit(); }
        }
    }
}


/*== Actualizando datos ==*/
$actualizar_producto = $pdo->prepare("UPDATE producto SET producto_codigo=:codigo, producto_nombre=:nombre, producto_precio=:precio, producto_stock=:stock, producto_detalle=:detalle, categoria_id=:categoria, producto_proveedor=:proveedor, estante_id=:estante WHERE producto_id=:id");

$marcadores = [
    ":codigo" => $codigo,
    ":nombre" => $nombre,
    ":precio" => $precio,
    ":stock" => $stock,
    ":detalle" => $detalle,
    ":categoria" => $categoria,
    ":proveedor" => $proveedor,
    ":estante" => $estante_id_final, 
    ":id" => $id
];

if ($actualizar_producto->execute($marcadores)) {
    echo json_encode([
        "success" => true,
        "message" => "Producto actualizado exitosamente",
        "redirect" => "/INV/index.php?vista=product_list"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error al actualizar el producto, no se guardaron los cambios"
    ]);
}

$pdo = null;
?>