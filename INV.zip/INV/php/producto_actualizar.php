<?php
require_once "main.php";

header('Content-Type: application/json');

/*== Almacenando id ==*/
$id = limpiar_cadena($_POST['producto_id']);

/*== Verificando producto ==*/
$pdo = conexion();
$check_producto = $pdo->prepare("SELECT * FROM producto WHERE producto_id = :id");
$check_producto->execute([':id' => $id]);

if ($check_producto->rowCount() <= 0) {
    echo json_encode(["success" => false, "message" => "El producto no existe en el sistema"]);
    exit();
} else {
    $datos = $check_producto->fetch(PDO::FETCH_ASSOC);
}

/*== Almacenando datos del formulario ==*/
$codigo = limpiar_cadena($_POST['producto_codigo']);
$nombre = limpiar_cadena($_POST['producto_nombre']);
$detalle = limpiar_cadena($_POST['producto_detalle']);
$precio = limpiar_cadena($_POST['producto_precio']);
$stock = limpiar_cadena($_POST['producto_stock']);
$categoria = limpiar_cadena($_POST['producto_categoria']);
$proveedor = limpiar_cadena($_POST['producto_proveedor']);
$estante_id = limpiar_cadena($_POST['estante_id']); // Modificado

/*== Verificando campos obligatorios ==*/
if ($codigo == "" || $nombre == "" || $precio == "" || $stock == "" || $categoria == "" || $detalle == "" || $proveedor == "" || $estante_id == "") {
    echo json_encode(["success" => false, "message" => "No has llenado todos los campos que son obligatorios"]);
    exit();
}

/*== GESTIÓN DE IMÁGENES ==*/
if (isset($_POST['imagenes_a_eliminar']) && is_array($_POST['imagenes_a_eliminar'])) {
    foreach ($_POST['imagenes_a_eliminar'] as $imagen_id) {
        $imagen_id = limpiar_cadena($imagen_id);
        
        $get_filename = $pdo->prepare("SELECT nombre_archivo FROM producto_imagenes WHERE imagen_id = :id AND producto_id = :pid");
        $get_filename->execute([':id' => $imagen_id, ':pid' => $id]);
        $filename = $get_filename->fetchColumn();

        if ($filename && is_file("../img/producto/" . $filename)) {
            unlink("../img/producto/" . $filename);
        }

        $delete_img = $pdo->prepare("DELETE FROM producto_imagenes WHERE imagen_id = :id AND producto_id = :pid");
        $delete_img->execute([':id' => $imagen_id, ':pid' => $id]);
    }
}

$img_dir = '../img/producto/';
if (isset($_FILES['producto_fotos_nuevas']) && !empty($_FILES['producto_fotos_nuevas']['name'][0])) {
    if (!file_exists($img_dir)) {
        if (!mkdir($img_dir, 0777, true)) {
            echo json_encode(["success" => false, "message" => "Error al crear el directorio de imágenes"]);
            exit();
        }
    }

    foreach ($_FILES['producto_fotos_nuevas']['name'] as $key => $nombre_foto) {
        if ($_FILES['producto_fotos_nuevas']['error'][$key] === UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['producto_fotos_nuevas']['tmp_name'][$key];

            if (!in_array(mime_content_type($tmp_name), ["image/jpeg", "image/png"])) {
                echo json_encode(["success" => false, "message" => "El archivo '$nombre_foto' tiene un formato no permitido."]);
                exit();
            }
            if (($_FILES['producto_fotos_nuevas']['size'][$key] / 1024) > 3072) {
                echo json_encode(["success" => false, "message" => "El archivo '$nombre_foto' supera las 3MB."]);
                exit();
            }

            $extension = pathinfo($nombre_foto, PATHINFO_EXTENSION);
            $nombre_archivo_unico = "prod_" . $id . "_" . time() . "_" . $key . "." . $extension;

            if (move_uploaded_file($tmp_name, $img_dir . $nombre_archivo_unico)) {
                $guardar_img = $pdo->prepare("INSERT INTO producto_imagenes(producto_id, nombre_archivo) VALUES(:pid, :nombre)");
                $guardar_img->execute([":pid" => $id, ":nombre" => $nombre_archivo_unico]);
            }
        }
    }
}

/*== Actualizando datos ==*/
$actualizar_producto = $pdo->prepare("UPDATE producto SET producto_codigo=:codigo, producto_nombre=:nombre, producto_precio=:precio, producto_stock=:stock, producto_detalle=:detalle, categoria_id=:categoria, producto_proveedor=:proveedor, estante_id=:estante WHERE producto_id=:id");

$marcadores = [
    ":codigo" => $codigo,
    ":nombre" => $nombre,
    ":precio" => $precio,
    ":stock" => $stock,
    ":detalle" => $detalle,
    ":categoria" => $categoria,
    ":proveedor" => $proveedor,
    ":estante" => $estante_id, // Modificado
    ":id" => $id
];

if ($actualizar_producto->execute($marcadores)) {
    echo json_encode([
        "success" => true,
        "message" => "Producto actualizado exitosamente",
        "redirect" => "/INV/index.php?vista=product_list"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error al actualizar el producto, no se guardaron los cambios"
    ]);
}

$pdo = null;
?>