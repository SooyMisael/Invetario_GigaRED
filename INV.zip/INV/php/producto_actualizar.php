<?php
require_once "main.php";

header('Content-Type: application/json');

/*== Almacenando id ==*/
$id = limpiar_cadena($_POST['producto_id']);

$pdo = conexion();

/*== Verificando producto ==*/
$check_producto = $pdo->prepare("SELECT * FROM producto WHERE producto_id = :id");
$check_producto->execute([':id' => $id]);

if ($check_producto->rowCount() <= 0) {
    echo json_encode(["success" => false, "message" => "El producto no existe en el sistema"]);
    exit();
} else {
    $datos = $check_producto->fetch(PDO::FETCH_ASSOC);
}

/*== Almacenando datos del formulario ==*/
$codigo = limpiar_cadena($_POST['producto_codigo']);
$nombre = limpiar_cadena($_POST['producto_nombre']);
$detalle = limpiar_cadena($_POST['producto_detalle']);

// MODIFICADO: Nuevos campos de precio
$producto_costo = limpiar_cadena($_POST['producto_costo']);
$producto_costo_moneda = limpiar_cadena($_POST['producto_costo_moneda']);
$producto_venta = limpiar_cadena($_POST['producto_venta']);
$producto_venta_moneda = limpiar_cadena($_POST['producto_venta_moneda']);

$stock = limpiar_cadena($_POST['producto_stock']);
$categoria = limpiar_cadena($_POST['producto_categoria']);
$proveedor = limpiar_cadena($_POST['producto_proveedor']);

// --- Datos de ubicación simplificados (Solo Estante) ---
$estante_id_seleccionado = limpiar_cadena($_POST['estante_id']);
$estante_nuevo_nombre = limpiar_cadena($_POST['estante_nuevo'] ?? '');
$estante_id_final = null;


/*== Verificando campos obligatorios ==*/
// MODIFICADO: Validación de nuevos campos
if ($codigo == "" || $nombre == "" || $producto_costo == "" || $producto_venta == "" || $stock == "" || $categoria == "" || $detalle == "" || $proveedor == "" || $estante_id_seleccionado == "") {
    echo json_encode(["success" => false, "message" => "No has llenado todos los campos que son obligatorios"]);
    exit();
}

// MODIFICADO: Validaciones de formato para precios
if (verificar_datos("[0-9.]{1,25}", $producto_costo)) {
    echo json_encode(["success" => false, "message" => "El PRECIO DE COSTO no coincide con el formato solicitado"]);
    exit();
}
if (verificar_datos("[0-9.]{1,25}", $producto_venta)) {
    echo json_encode(["success" => false, "message" => "El PRECIO DE VENTA no coincide con el formato solicitado"]);
    exit();
}


/*== Lógica para manejar la ubicación (Solo Estante) ==*/
if ($estante_id_seleccionado == 'crear_nuevo') {
    if (empty($estante_nuevo_nombre)) {
        echo json_encode(["success" => false, "message" => "Debes especificar un nombre para el nuevo estante"]);
        exit();
    }
    // Asumiendo que la tabla 'estantes' ya no tiene 'almacen_id'
    $stmt = $pdo->prepare("INSERT INTO estantes(nombre) VALUES(:nombre)");
    $stmt->execute([':nombre' => $estante_nuevo_nombre]);
    $estante_id_final = $pdo->lastInsertId();
} else {
    $estante_id_final = (int)$estante_id_seleccionado;
}

if(empty($estante_id_final) || !is_numeric($estante_id_final)) {
    echo json_encode(["success" => false, "message" => "La ubicación final (estante) no pudo ser determinada o no es válida."]);
    exit();
}


/*== GESTIÓN DE IMÁGENES ==*/
if (isset($_POST['imagenes_a_eliminar']) && is_array($_POST['imagenes_a_eliminar'])) {
    foreach ($_POST['imagenes_a_eliminar'] as $imagen_id) {
        $imagen_id = limpiar_cadena($imagen_id);
        $get_filename = $pdo->prepare("SELECT nombre_archivo FROM producto_imagenes WHERE imagen_id = :id AND producto_id = :pid");
        $get_filename->execute([':id' => $imagen_id, ':pid' => $id]);
        $filename = $get_filename->fetchColumn();
        if ($filename && is_file("../img/producto/" . $filename)) {
            unlink("../img/producto/" . $filename);
        }
        $delete_img = $pdo->prepare("DELETE FROM producto_imagenes WHERE imagen_id = :id AND producto_id = :pid");
        $delete_img->execute([':id' => $imagen_id, ':pid' => $id]);
    }
}
$img_dir = '../img/producto/';
if (isset($_FILES['producto_fotos_nuevas']) && !empty($_FILES['producto_fotos_nuevas']['name'][0])) {
    if (!file_exists($img_dir)) {
        if (!mkdir($img_dir, 0777, true)) { echo json_encode(["success" => false, "message" => "Error al crear directorio"]); exit(); }
    }
    foreach ($_FILES['producto_fotos_nuevas']['name'] as $key => $nombre_foto) {
        if ($_FILES['producto_fotos_nuevas']['error'][$key] === UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['producto_fotos_nuevas']['tmp_name'][$key];
            if (!in_array(mime_content_type($tmp_name), ["image/jpeg", "image/png"])) { echo json_encode(["success" => false, "message" => "'$nombre_foto': formato no permitido."]); exit(); }
            if (($_FILES['producto_fotos_nuevas']['size'][$key] / 1024) > 3072) { echo json_encode(["success" => false, "message" => "'$nombre_foto' supera 3MB."]); exit(); }
            $extension = pathinfo($nombre_foto, PATHINFO_EXTENSION);
            $nombre_archivo_unico = "prod_" . $id . "_" . time() . "_" . $key . "." . $extension;
            if (move_uploaded_file($tmp_name, $img_dir . $nombre_archivo_unico)) {
                $guardar_img = $pdo->prepare("INSERT INTO producto_imagenes(producto_id, nombre_archivo) VALUES(:pid, :nombre)");
                $guardar_img->execute([":pid" => $id, ":nombre" => $nombre_archivo_unico]);
            } else { echo json_encode(["success" => false, "message" => "Error al mover '$nombre_foto'"]); exit(); }
        }
    }
}


/*== Actualizando datos ==*/
// MODIFICADO: Consulta SQL con nuevos campos
$actualizar_producto = $pdo->prepare("UPDATE producto SET 
    producto_codigo=:codigo, producto_nombre=:nombre, 
    producto_costo=:costo, producto_costo_moneda=:costo_moneda, 
    producto_venta=:venta, producto_venta_moneda=:venta_moneda, 
    producto_stock=:stock, producto_detalle=:detalle, categoria_id=:categoria, 
    producto_proveedor=:proveedor, estante_id=:estante 
    WHERE producto_id=:id");

$marcadores = [
    ":codigo" => $codigo,
    ":nombre" => $nombre,
    // MODIFICADO: Marcadores de nuevos campos
    ":costo" => $producto_costo,
    ":costo_moneda" => $producto_costo_moneda,
    ":venta" => $producto_venta,
    ":venta_moneda" => $producto_venta_moneda,
    ":stock" => $stock,
    ":detalle" => $detalle,
    ":categoria" => $categoria,
    ":proveedor" => $proveedor,
    ":estante" => $estante_id_final, 
    ":id" => $id
];

// 3. DESPUÉS DEL UPDATE: Si hubo cambios, guardarlos
if ($actualizar_producto->execute($marcadores)) {
    
    // --- LÓGICA PARA HISTORIAL DE CAMBIOS ---
    $cambios = [];
    if ($datos['producto_nombre'] != $nombre) $cambios[] = "Nombre cambiado";
    if ($datos['producto_venta'] != $producto_venta) $cambios[] = "Precio Venta: $ " . $datos['producto_venta'] . " -> $ " . $producto_venta;
    if ($datos['producto_stock'] != $stock) $cambios[] = "Stock: " . $datos['producto_stock'] . " -> " . $stock;
    // ... (puedes añadir más)

    if (count($cambios) > 0) {
        $detalles = implode(", ", $cambios);
        registrar_historial($id, 'Actualizar', $detalles, $pdo);
    }
    // ---------------------------------------

    echo json_encode([
        "success" => true,
        "message" => "Producto actualizado exitosamente",
        "redirect" => "/INV/index.php?vista=product_list"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error al actualizar el producto, no se guardaron los cambios"
    ]);
}

$pdo = null;
?>