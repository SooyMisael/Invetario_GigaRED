<?php
require_once "main.php"; 

/*== Almacenando id ==*/
$product_id_del = limpiar_cadena($_GET['product_id_del']);

/*== Verificando si el producto existe ==*/
$pdo = conexion();
$check_producto = $pdo->prepare("SELECT producto_id FROM producto WHERE producto_id = :id");
$check_producto->execute([':id' => $product_id_del]);

if ($check_producto->rowCount() != 1) {
    // Producto no encontrado, redirigir
    header("Location: ../index.php?vista=product_list&deleted=notfound");
    exit();
}
$check_producto = null; 

// --- Si el producto existe, proceder a eliminar ---

// 1. Buscar y eliminar imágenes asociadas
$check_imagenes = $pdo->prepare("SELECT nombre_archivo FROM producto_imagenes WHERE producto_id = :id");
$check_imagenes->execute([':id' => $product_id_del]);
$imagenes = $check_imagenes->fetchAll(PDO::FETCH_ASSOC);
$check_imagenes = null; // Liberar consulta

$img_dir = '../img/producto/';
foreach ($imagenes as $img) {
    if (!empty($img['nombre_archivo']) && is_file($img_dir . $img['nombre_archivo'])) {
        unlink($img_dir . $img['nombre_archivo']);
    }
}

// 2. Eliminar referencias de imágenes en la base de datos
$eliminar_img_refs = $pdo->prepare("DELETE FROM producto_imagenes WHERE producto_id = :id");
$eliminar_img_refs->execute([':id' => $product_id_del]);
$eliminar_img_refs = null; // Liberar consulta

// 3. Eliminar el producto principal
$eliminar_producto = $pdo->prepare("DELETE FROM producto WHERE producto_id=:id");
$eliminar_producto->execute([":id" => $product_id_del]);

// 4. Verificar resultado y redirigir
if ($eliminar_producto->rowCount() == 1) {
    header("Location: ../index.php?vista=product_list&deleted=ok");
} else {
    header("Location: ../index.php?vista=product_list&deleted=error");
}

$eliminar_producto = null; 
$pdo = null; 
exit(); 

?>