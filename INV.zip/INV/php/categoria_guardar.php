<?php
require_once "main.php";

// Definir que la respuesta siempre será JSON
header('Content-Type: application/json');

/*== Almacenando datos ==*/
$nombre = limpiar_cadena($_POST['categoria_nombre']);
$ubicacion_seleccionada = limpiar_cadena($_POST['categoria_ubicacion'] ?? ''); // Ubicación del select
$ubicacion_nueva = limpiar_cadena($_POST['input_ubicacion_nueva'] ?? ''); // Ubicación del input

// Determinar la ubicación final
$ubicacion = $ubicacion_nueva ?: $ubicacion_seleccionada;

// Convertir a mayúsculas
$nombre = strtoupper($nombre);
$ubicacion = strtoupper($ubicacion);

/*== Verificando campos obligatorios ==*/
if ($nombre == "" || $ubicacion == "") { // Ahora ubicación también es obligatoria
    echo json_encode(["success" => false, "message" => "El nombre y la ubicación son obligatorios"]);
    exit();
}

/*== Verificando integridad de los datos ==*/
if (verificar_datos("[A-Z0-9ÁÉÍÓÚÑ ]{2,50}", $nombre)) {
    echo json_encode(["success" => false, "message" => "El NOMBRE no coincide con el formato solicitado (solo mayúsculas, números y espacios, 2-50 caracteres)"]);
    exit();
}

if (verificar_datos("[A-Z0-9ÁÉÍÓÚÑ ]{2,150}", $ubicacion)) {
    echo json_encode(["success" => false, "message" => "La UBICACIÓN no coincide con el formato solicitado (solo mayúsculas, números y espacios, 2-150 caracteres)"]);
    exit();
}

/*== Verificando que la combinación Nombre y Ubicación no exista ==*/
$pdo = conexion();
$check_duplicado = $pdo->prepare("SELECT categoria_id FROM categoria WHERE categoria_nombre = :nombre AND categoria_ubicacion = :ubicacion");
$check_duplicado->execute([':nombre' => $nombre, ':ubicacion' => $ubicacion]);

if ($check_duplicado->rowCount() > 0) {
    // Mensaje específico para categoría duplicada
    echo json_encode(["success" => false, "message" => "La categoría '$nombre' ya se encuentra registrada en la ubicación '$ubicacion'."]);
    exit();
}
$check_duplicado = null; // Cerrar la consulta

/*== Guardando datos en la base de datos ==*/
$guardar_categoria = $pdo->prepare("INSERT INTO categoria(categoria_nombre,categoria_ubicacion) VALUES(:nombre,:ubicacion)");

$marcadores = [
    ":nombre" => $nombre,
    ":ubicacion" => $ubicacion
];

$guardar_categoria->execute($marcadores);

/*== Respuesta final ==*/
if ($guardar_categoria->rowCount() == 1) {
    // Mensaje específico de éxito
    echo json_encode([
        "success" => true,
        "message" => "¡Categoría registrada exitosamente!",
        "redirect" => "/INV/index.php?vista=category_list" // Mantener redirección si la necesitas
    ]);
} else {
    // Mensaje específico de error al guardar
    echo json_encode([
        "success" => false,
        "message" => "No se pudo registrar la categoría, por favor intente nuevamente."
    ]);
}
$pdo = null; // Cerrar la conexión principal

?>