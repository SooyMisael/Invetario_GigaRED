<?php
require_once "../inc/session_start.php";
require_once "main.php";

header('Content-Type: application/json');

/*== Almacenando datos ==*/
$codigo = limpiar_cadena($_POST['producto_codigo']);
$nombre = limpiar_cadena($_POST['producto_nombre']);
$precio = limpiar_cadena($_POST['producto_precio']);
$stock = limpiar_cadena($_POST['producto_stock']);
$categoria = limpiar_cadena($_POST['producto_categoria']);
$detalle = limpiar_cadena($_POST['producto_detalle']);
$proveedor = limpiar_cadena($_POST['producto_proveedor']);
$paquete = isset($_POST['producto_paquete']) ? limpiar_cadena($_POST['producto_paquete']) : 0;
$condicion = limpiar_cadena($_POST['producto_condicion']);

// --- Datos de la nueva ubicación ---
$almacen_id_seleccionado = limpiar_cadena($_POST['almacen_id']);
$almacen_nuevo_nombre = limpiar_cadena($_POST['almacen_nuevo'] ?? '');
$estante_id_seleccionado = limpiar_cadena($_POST['estante_id']);
$estante_nuevo_nombre = limpiar_cadena($_POST['estante_nuevo'] ?? '');
$estante_id_final = null;


/*== Verificando campos obligatorios ==*/
if ($codigo == "" || $nombre == "" || $precio == "" || $stock == "" || $categoria == "" || $detalle == "" || $proveedor == "" || $condicion == "" || $almacen_id_seleccionado == "") {
    echo json_encode(["success" => false, "message" => "No has llenado todos los campos que son obligatorios"]);
    exit();
}

/*== Verificando integridad de los datos ==*/
if (verificar_datos("[0-9.]{1,70}", $codigo)) {
    echo json_encode(["success" => false, "message" => "El CÓDIGO de BARRAS no coincide con el formato solicitado"]);
    exit();
}
// ... (Tus otras verificaciones de formato aquí) ...

$pdo = conexion();

/*== Lógica para manejar la ubicación (Almacén y Estante) ==*/
$almacen_id_final = $almacen_id_seleccionado;

if ($almacen_id_seleccionado == 'crear_nuevo') {
    if (empty($almacen_nuevo_nombre)) {
        echo json_encode(["success" => false, "message" => "Debes especificar un nombre para el nuevo almacén"]);
        exit();
    }
    $stmt = $pdo->prepare("INSERT INTO almacenes(nombre) VALUES(:nombre)");
    $stmt->execute([':nombre' => $almacen_nuevo_nombre]);
    $almacen_id_final = $pdo->lastInsertId();
}

if ($estante_id_seleccionado == 'crear_nuevo') {
    if (empty($estante_nuevo_nombre)) {
        echo json_encode(["success" => false, "message" => "Debes especificar un nombre para el nuevo estante"]);
        exit();
    }
    if (empty($almacen_id_final)) {
        echo json_encode(["success" => false, "message" => "Un nuevo estante debe estar asociado a un almacén"]);
        exit();
    }
    $stmt = $pdo->prepare("INSERT INTO estantes(nombre, almacen_id) VALUES(:nombre, :almacen_id)");
    $stmt->execute([':nombre' => $estante_nuevo_nombre, ':almacen_id' => $almacen_id_final]);
    $estante_id_final = $pdo->lastInsertId();
} else {
    $estante_id_final = (int)$estante_id_seleccionado;
}

if(empty($estante_id_final)) {
    echo json_encode(["success" => false, "message" => "La ubicación final (estante) no pudo ser determinada."]);
    exit();
}

/*== Verificando código ==*/
$check_codigo = $pdo->query("SELECT producto_codigo FROM producto WHERE producto_codigo='$codigo'");
if ($check_codigo->rowCount() > 0) {
    echo json_encode(["success" => false, "message" => "El CÓDIGO de BARRAS ingresado ya se encuentra registrado, por favor elija otro"]);
    exit();
}

/*== Verificando nombre ==*/
$check_nombre = $pdo->query("SELECT producto_nombre FROM producto WHERE producto_nombre='$nombre'");
if ($check_nombre->rowCount() > 0) {
    echo json_encode(["success" => false, "message" => "El NOMBRE ingresado ya se encuentra registrado, por favor elija otro"]);
    exit();
}

/*== Verificando categoría ==*/
$check_categoria = $pdo->query("SELECT categoria_id FROM categoria WHERE categoria_id='$categoria'");
if ($check_categoria->rowCount() <= 0) {
    echo json_encode(["success" => false, "message" => "La categoría seleccionada no existe"]);
    exit();
}

/*== Guardando datos ==*/
$guardar_producto = $pdo->prepare("INSERT INTO producto(producto_codigo,producto_nombre,producto_precio,producto_stock,producto_detalle,categoria_id, producto_proveedor,producto_paquete, producto_condicion, estante_id) VALUES(:codigo,:nombre,:precio,:stock,:detalle,:categoria, :proveedor, :paquete, :condicion, :estante_id)");

$marcadores = [
    ":codigo" => $codigo,
    ":nombre" => $nombre,
    ":precio" => $precio,
    ":stock" => $stock,
    ":detalle" => $detalle,
    ":categoria" => $categoria,
    ":proveedor" => $proveedor,
    ":paquete" => $paquete,
    ":condicion" => $condicion,
    ":estante_id" => $estante_id_final
];

$guardar_producto->execute($marcadores);

if ($guardar_producto->rowCount() == 1) {
    
    $producto_id_nuevo = $pdo->lastInsertId();
    $img_dir = '../img/producto/';

    if (isset($_FILES['producto_fotos']) && count($_FILES['producto_fotos']['name']) > 0) {
        if (!file_exists($img_dir)) {
            if (!mkdir($img_dir, 0777, true)) {
                echo json_encode(["success" => false, "message" => "Error al crear el directorio de imágenes"]);
                exit();
            }
        }
        foreach ($_FILES['producto_fotos']['name'] as $key => $nombre_foto) {
            if ($_FILES['producto_fotos']['error'][$key] === UPLOAD_ERR_OK) {
                $tmp_name = $_FILES['producto_fotos']['tmp_name'][$key];

                if (!in_array(mime_content_type($tmp_name), ["image/jpeg", "image/png"])) {
                    echo json_encode(["success" => false, "message" => "El archivo ".$nombre_foto." tiene un formato no permitido."]);
                    exit();
                }

                if (($_FILES['producto_fotos']['size'][$key] / 1024) > 3072) {
                    echo json_encode(["success" => false, "message" => "El archivo ".$nombre_foto." supera las 3MB."]);
                    exit();
                }

                $extension = pathinfo($nombre_foto, PATHINFO_EXTENSION);
                $nombre_archivo_unico = "prod_" . $producto_id_nuevo . "_" . time() . "_" . $key . "." . $extension;
                
                if (move_uploaded_file($tmp_name, $img_dir . $nombre_archivo_unico)) {
                    $guardar_img = $pdo->prepare("INSERT INTO producto_imagenes(producto_id, nombre_archivo) VALUES(:pid, :nombre)");
                    $guardar_img->execute([
                        ":pid" => $producto_id_nuevo,
                        ":nombre" => $nombre_archivo_unico
                    ]);
                } else {
                    echo json_encode(["success" => false, "message" => "Error al mover el archivo ".$nombre_foto]);
                    exit();
                }
            }
        }
    }

    echo json_encode([
        "success" => true,
        "message" => "¡Producto registrado exitosamente!",
        "redirect" => "/INV/index.php?vista=product_list"
    ]);

} else {
    echo json_encode([
        "success" => false,
        "message" => "No se pudo registrar el producto, por favor intente nuevamente."
    ]);
}
$pdo = null;