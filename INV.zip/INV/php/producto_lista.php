<?php 
    
    #Calcular la paginacion de la pagina
    $inicio = ($pagina>0) ? (($pagina * $registros)-$registros) : 0;
    $tabla="";

    #Definir los campos en las consultas
    $campos = "producto.producto_id, producto.producto_codigo, producto.producto_nombre, 
               producto.producto_costo, producto.producto_costo_moneda, producto.producto_venta, producto.producto_venta_moneda, 
               producto.producto_stock, producto.producto_proveedor, producto.producto_paquete, producto.producto_condicion, 
               categoria.categoria_nombre, estantes.nombre AS nombre_estante, 
               (SELECT nombre_archivo FROM producto_imagenes WHERE producto_imagenes.producto_id = producto.producto_id ORDER BY orden ASC, imagen_id ASC LIMIT 1) AS imagen_principal";

    $joins = "FROM producto 
              INNER JOIN categoria ON producto.categoria_id=categoria.categoria_id 
              LEFT JOIN estantes ON producto.estante_id = estantes.estante_id";

    #Existe alguna busqueda
    if(isset($busqueda) && $busqueda!=""){
        $consulta_datos = "SELECT $campos $joins WHERE producto.producto_codigo LIKE '%$busqueda%' OR producto.producto_nombre LIKE '%$busqueda%' ORDER BY producto.producto_nombre ASC LIMIT $inicio,$registros";
        $consulta_total="SELECT COUNT(producto_id) FROM producto WHERE producto_codigo LIKE '%$busqueda%' OR producto_nombre LIKE '%$busqueda%'";

    }elseif($categoria_id>0){
         $consulta_datos = "SELECT $campos $joins WHERE producto.categoria_id='$categoria_id' ORDER BY producto.producto_nombre ASC LIMIT $inicio,$registros";
        $consulta_total="SELECT COUNT(producto_id) FROM producto WHERE categoria_id='$categoria_id'";

    }else{
        $consulta_datos = "SELECT $campos $joins ORDER BY producto.producto_nombre ASC LIMIT $inicio,$registros";
        $consulta_total="SELECT COUNT(producto_id) FROM producto";
    }

    $conexion=conexion();
    $datos = $conexion->query($consulta_datos);
    $datos = $datos->fetchAll();
    $total = $conexion->query($consulta_total);
    $total = (int) $total->fetchColumn();
    $Npaginas =ceil($total/$registros);
    $vista_actual = $_GET['vista'] ?? "home";

    if($total>=1 && $pagina<=$Npaginas){
        $contador=$inicio+1;
        $pag_inicio=$inicio+1;
        foreach($datos as $rows){

            $tabla.='
                <article class="media is-vcentered">
                    <figure class="media-left">';
            
            if(!empty($rows['imagen_principal']) && is_file("./img/producto/".$rows['imagen_principal'])){
                $imagen_url = './img/producto/'.$rows['imagen_principal'];
            }else{
                $imagen_url = './img/producto.png';
            }
            
            if($vista_actual == "product_list") {
                $tabla.='
                    <div class="image-zoom-container">
                        <p class="image is-64x64">
                            <img src="'.$imagen_url.'" alt="'.htmlspecialchars($rows['producto_nombre']).'">
                        </p>
                        <img src="'.$imagen_url.'" class="zoomed-image">
                    </div>';
            } else {
                $tabla.='
                    <p class="image is-64x64">
                        <img src="'.$imagen_url.'" alt="'.htmlspecialchars($rows['producto_nombre']).'">
                    </p>';
            }

            $tabla.='
                    </figure>
                    <div class="media-content">
                        <div class="content">
                        <p>
                            '.$contador.' - <strong>'.htmlspecialchars($rows['producto_nombre']).'</strong> - (<strong>'.$rows['producto_stock'].'</strong>)<br>

                            COSTO: <strong class="has-text-grey-dark">$'.number_format($rows['producto_costo'], 2).' '.htmlspecialchars($rows['producto_costo_moneda']).'</strong>,
                            VENTA: <strong class="has-text-success-dark">$'.number_format($rows['producto_venta'], 2).' '.htmlspecialchars($rows['producto_venta_moneda']).'</strong><br>
                            
                            '.(($rows['producto_paquete'] > 0) ? 'PAQUETE DE: <strong>'.$rows['producto_paquete']. '</strong> PIEZAS,'  :  '').'
                            ESTADO: <strong>'.$rows['producto_condicion'].'</strong>,
                            UBICACIÓN: <strong>'.htmlspecialchars($rows['nombre_estante'] ?? 'Sin Asignar').'</strong>
                        </p>

                        </div>
                    </div>
                    
                    <div class="media-right">
                        <div class="field is-grouped">
            ';
            
            if($vista_actual=="product_list"){
                $tabla.='
                    <form action="./php/producto_stock.php" method="POST" style="display:inline-block;">
                        <input type="hidden" name="producto_id" value="'.$rows['producto_id'].'">
                        <input type="hidden" name="vista_actual" value="'.$vista_actual.'">
                        <div class="field has-addons">
                            <p class="control">
                                <button class="button is-small button-stock-custom" type="submit" name="accion" value="menos">-</button>
                            </p>
                            <p class="control">
                                <input class="input is-small" type="text" value="'.$rows['producto_stock'].'" readonly style="width:50px; text-align:center;">
                            </p>
                            <p class="control">
                                <button class="button is-small button-stock-custom" type="submit" name="accion" value="mas">+</button>
                            </p>
                        </div>
                    </form>
                ';
            }else{
                $tabla.='
                    <span class="tag is-info is-medium" style="margin-left:10px;">
                        Stock: '.$rows['producto_stock'].'
                    </span>
                ';
            }

            $tabla.='
                            <div class="dropdown is-right is-hoverable ml-2">
                                <div class="dropdown-trigger">
                                    <button class="button is-small button-acciones-custom has-tooltip-arrow has-tooltip-left" 
                                            aria-haspopup="true" 
                                            aria-controls="dropdown-menu-'.$rows['producto_id'].'"
                                            data-tooltip="Ver, actualizar o eliminar">
                                    <span>Acciones</span>
                                        <span class="icon is-small">
                                            <i class="fas fa-angle-down" aria-hidden="true"></i>
                                        </span>
                                    </button>
                                </div>
                                <div class="dropdown-menu" id="dropdown-menu-'.$rows['producto_id'].'" role="menu">
                                    <div class="dropdown-content">
                                        
                                        <a href="index.php?vista=product_img&product_id_up='.$rows['producto_id'].'" 
                                           class="dropdown-item has-tooltip has-tooltip-arrow has-tooltip-left" 
                                           data-tooltip="Ver todos los detalles del producto">
                                            <span class="icon is-small"><i class="fas fa-eye" aria-hidden="true"></i></span>
                                            <span>Ver Detalles</span>
                                        </a>
            ';
            if($vista_actual == "product_list"){
            $tabla.='
                                        <hr class="dropdown-divider">
                                        <a href="index.php?vista=product_update&product_id_up='.$rows['producto_id'].'" 
                                           class="dropdown-item has-tooltip has-tooltip-arrow has-tooltip-left" 
                                           data-tooltip="Editar la información de este producto">
                                            <span class="icon is-small"><i class="fas fa-pencil-alt" aria-hidden="true"></i></span>
                                            <span>Actualizar</span>
                                        </a>
                                        <a href="#" 
                                           class="dropdown-item js-delete-button has-text-danger has-tooltip has-tooltip-arrow has-tooltip-left" 
                                           data-tooltip="Eliminar este producto del inventario" 
                                           data-id="'.$rows['producto_id'].'" data-nombre="'.htmlspecialchars($rows['producto_nombre']).'">
                                            <span class="icon is-small has-text-danger"><i class="fas fa-trash" aria-hidden="true"></i></span>
                                            <span>Eliminar</span>
                                        </a>
                                        ';
            }
            $tabla.='
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </article>
                <hr>
            ';
            
            $contador++;
        }
        $pag_final=$contador-1;
    }else{
        if($total>=1){
            $tabla.='<p class="has-text-centered" ><a href="'.$url.'1" class="button is-link is-small mt-4 mb-4">Haga clic acá para recargar el listado</a></p>';
        }else{
            $tabla.='<p class="has-text-centered" >No hay registros en el sistema</p>';
        }
    }

    if($total>0 && $pagina<=$Npaginas){
        $tabla.='<p class="has-text-right">Mostrando productos <strong>'.$pag_inicio.'</strong> al <strong>'.$pag_final.'</strong> de un <strong>total de '.$total.'</strong></p>';
    }

    $conexion=null;
    echo $tabla;

    if($total>=1 && $pagina<=$Npaginas){
        echo paginador_tablas($pagina,$Npaginas,$url,7);
    }
?>