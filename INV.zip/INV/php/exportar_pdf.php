<?php

require_once "main.php";
require_once "../fpdf/fpdf.php";


class PDF extends FPDF
{
    
    function Header()
    {
        
        $this->Image('../img/GIGA-RED.jpeg', 10, 5, 33);
        
       
        $this->SetFont('Arial', 'B', 12);
        
        
        $this->Cell(80);
        
        
        $this->Cell(30, 10, utf8_decode('Reporte de Productos'), 0, 0, 'C');
        
        
        $this->SetFont('Arial', '', 10);
        $this->Cell(80, 10, 'Fecha: ' . date('d/m/Y'), 0, 0, 'R');

        
        $this->Ln(25);
    }

    
    function Footer()
    {
        
        $this->SetY(-15);
        
        $this->SetFont('Arial', 'I', 8);
        
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}


$pdf = new PDF();
$pdf->AliasNbPages(); 
$pdf->AddPage(); 
$pdf->SetFont('Arial', '', 12); 


$conexion = conexion();


$consulta_productos = $conexion->query("
    SELECT p.producto_proveedor, p.producto_nombre, p.producto_precio, p.producto_stock, c.categoria_ubicacion
    FROM producto p
    INNER JOIN categoria c ON p.categoria_id = c.categoria_id
    ORDER BY p.producto_nombre ASC
");


$pdf->SetFillColor(232, 232, 232); 
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(40, 10, 'Proveedor', 1, 0, 'C', 1);
$pdf->Cell(60, 10, 'Nombre', 1, 0, 'C', 1);
$pdf->Cell(30, 10, 'Precio', 1, 0, 'C', 1);
$pdf->Cell(25, 10, 'Cantidad', 1, 0, 'C', 1);
$pdf->Cell(35, 10, 'Ubicacion', 1, 1, 'C', 1);


$pdf->SetFont('Arial', '', 10);

if ($consulta_productos->rowCount() > 0) {
    $productos = $consulta_productos->fetchAll();
    foreach ($productos as $producto) {
        $pdf->Cell(40, 10, utf8_decode($producto['producto_proveedor']), 1, 0, 'L');
        $pdf->Cell(60, 10, utf8_decode($producto['producto_nombre']), 1, 0, 'L');
        $pdf->Cell(30, 10, '$' . number_format($producto['producto_precio'], 2), 1, 0, 'R');
        $pdf->Cell(25, 10, $producto['producto_stock'], 1, 0, 'C');
        $pdf->Cell(35, 10, utf8_decode($producto['categoria_ubicacion']), 1, 1, 'L');
    }
} else {
    $pdf->Cell(190, 10, utf8_decode('No hay productos registrados.'), 1, 1, 'C');
}


$conexion = null;


$pdf->Output('D', 'Lista_de_Productos.pdf'); 