<?php

date_default_timezone_set('America/Tijuana');
require_once "main.php";
require_once "../fpdf/fpdf.php";

class PDF extends FPDF
{
    function Header()
    {
        $this->Image('../img/GIGA-RED.jpeg', 10, 5, 33);
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(190, 10, utf8_decode('Reporte de Productos'), 0, 1, 'C');
        $this->SetFont('Arial', '', 9);
        $this->Cell(190, 5, utf8_decode('Generado: ') . date('d/m/Y H:i:s'), 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}


$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

$pdf->SetDrawColor(217, 217, 214); 

// === ENCABEZADOS DE TABLA MODIFICADOS ===
// Se ajustaron los anchos y se regresó a "Ubicacion"
$pdf->SetFillColor(232, 232, 232);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(50, 10, 'Nombre', 1, 0, 'C', 1);
$pdf->Cell(35, 10, 'Proveedor', 1, 0, 'C', 1);
$pdf->Cell(30, 10, 'Costo', 1, 0, 'C', 1);
$pdf->Cell(30, 10, 'Venta', 1, 0, 'C', 1);
$pdf->Cell(20, 10, 'Cantidad', 1, 0, 'C', 1);
$pdf->Cell(25, 10, 'Ubicacion', 1, 1, 'C', 1); // Regresa a "Ubicacion"

$conexion = conexion();

// === CONSULTA SQL MODIFICADA ===
// Se traen los nuevos campos de precio y la 'categoria_ubicacion' original
$consulta_productos = $conexion->query("
    SELECT p.producto_proveedor, p.producto_nombre, p.producto_stock,
           p.producto_costo, p.producto_costo_moneda,
           p.producto_venta, p.producto_venta_moneda,
           c.categoria_ubicacion
    FROM producto p
    INNER JOIN categoria c ON p.categoria_id = c.categoria_id
    ORDER BY p.producto_nombre ASC
");

if ($consulta_productos->rowCount() > 0) {
    $productos = $consulta_productos->fetchAll();
    foreach ($productos as $producto) {
        $pdf->SetFont('Arial', '', 9);

        // Acortar nombre de producto si es muy largo
        $nombre_producto = $producto['producto_nombre'];
        if (strlen($nombre_producto) > 28) { // Ajustado para 50 de ancho
            $nombre_producto = substr($nombre_producto, 0, 25) . '...';
        }

        // Formatear los precios con su moneda
        $costo = '$' . number_format($producto['producto_costo'], 2) . ' ' . $producto['producto_costo_moneda'];
        $venta = '$' . number_format($producto['producto_venta'], 2) . ' ' . $producto['producto_venta_moneda'];

        // === CELDAS DE DATOS MODIFICADAS ===
        $pdf->Cell(50, 10, utf8_decode($nombre_producto), 1, 0, 'L');
        $pdf->Cell(35, 10, utf8_decode($producto['producto_proveedor']), 1, 0, 'L');
        $pdf->Cell(30, 10, utf8_decode($costo), 1, 0, 'R');
        $pdf->Cell(30, 10, utf8_decode($venta), 1, 0, 'R');
        $pdf->Cell(20, 10, $producto['producto_stock'], 1, 0, 'C');
        $pdf->Cell(25, 10, utf8_decode($producto['categoria_ubicacion']), 1, 1, 'L'); // Regresa a 'categoria_ubicacion'
    }
} else {
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(190, 10, utf8_decode('No hay productos registrados.'), 1, 1, 'C');
}

$conexion = null;

$fecha_actual = date('Y-m-d_His'); 
$nombre_archivo = 'Reporte_Productos_' . $fecha_actual . '.pdf';

$pdf->Output('D', $nombre_archivo);