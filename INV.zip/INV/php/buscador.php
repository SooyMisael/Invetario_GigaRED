<?php
$modulo_buscador = limpiar_cadena($_POST['modulo_buscador']);
$vista_actual = limpiar_cadena($_POST['vista_actual'] ?? 'home');
$redirect_url_error = "index.php?vista=" . $vista_actual; 
$modulos = ["categoria", "producto"];

if (in_array($modulo_buscador, $modulos)) {
    
    $modulos_url = [
        "categoria" => "category_search",
        "producto" => "product_search"
    ];

    $modulos_url = $modulos_url[$modulo_buscador];
    $modulo_buscador = "busqueda_" . $modulo_buscador;

    # Iniciar busqueda #
    if (isset($_POST['txt_buscador'])) {

        $txt = limpiar_cadena($_POST['txt_buscador']);

        if ($txt == "") {
            
            $_SESSION['toast_message'] = "Debes introducir un término de búsqueda";
            $_SESSION['toast_type'] = "error";
            header("Location: $redirect_url_error"); 
            exit();
        } else {
            if (verificar_datos("[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]{1,30}", $txt)) {
                $_SESSION['toast_message'] = "El término de búsqueda no coincide con el formato solicitado";
                $_SESSION['toast_type'] = "error";
                header("Location: $redirect_url_error"); 
                exit();
            } else {
                $_SESSION[$modulo_buscador] = $txt;
                header("Location: index.php?vista=$modulos_url", true, 303); 
                exit();   
            }
        }
    }

    # Eliminar busqueda #
    if (isset($_POST['eliminar_buscador'])) {
        unset($_SESSION[$modulo_buscador]);
        header("Location: index.php?vista=$modulos_url", true, 303); 
        exit();
    }

} else {
    $_SESSION['toast_message'] = "No podemos procesar la petición";
    $_SESSION['toast_type'] = "error";
    header("Location: $redirect_url_error"); 
    exit();
}