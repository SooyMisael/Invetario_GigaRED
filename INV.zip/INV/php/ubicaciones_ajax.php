<?php
require_once "main.php";
header('Content-Type: application/json');

$pdo = conexion();
$response = [];

if (isset($_GET['almacen_id'])) {
    $stmt = $pdo->prepare("SELECT estante_id, nombre FROM estantes WHERE almacen_id = :id ORDER BY nombre");
    $stmt->execute([':id' => $_GET['almacen_id']]);
    $response = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

echo json_encode($response);