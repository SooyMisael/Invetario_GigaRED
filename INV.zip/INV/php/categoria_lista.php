<?php
#Permite Buscar las categorias que se encuentran en la lista
#Muestra los resultados en una tabla que contiene diferentes opciones para las categorias
#Tales como ver producto, actualizar y Eliminar
#Solo se pueden eliminar las categorias cuando no se tenga ningun producto asociado.#


# Calculo para la paginacion #
$inicio = ($pagina>0) ? (($pagina * $registros)-$registros) : 0;
$tabla="";


# Consultas SQL #
if(isset($busqueda) && $busqueda!=""){

    # Consulta para traer las categorias dependiendo la busqueda#
    # Parte de codigo que afecta al buscador, manda la tabla con lo buscado #
    $consulta_datos="SELECT * FROM categoria WHERE categoria_nombre LIKE '%$busqueda%' OR categoria_ubicacion LIKE '%$busqueda%' ORDER BY categoria_nombre ASC LIMIT $inicio,$registros";

    # Consulta para contar los resultados para la paginacion #
    $consulta_total="SELECT COUNT(categoria_id) FROM categoria WHERE categoria_nombre LIKE '%$busqueda%' OR categoria_ubicacion LIKE '%$busqueda%'";

}else{
    # Trae todos los resultados porque no se tiene busqueda#
    $consulta_datos="SELECT * FROM categoria ORDER BY categoria_nombre ASC LIMIT $inicio,$registros";
    # Cuenta todas las categorias para la paginacion #
    $consulta_total="SELECT COUNT(categoria_id) FROM categoria";
    
}

# Realiza la conexion a la BD #
$conexion=conexion();

# Trae los datos de categorias #
$datos = $conexion->query($consulta_datos);
$datos = $datos->fetchAll();

# Variable para contar el total de registros #
$total = $conexion->query($consulta_total);
$total = (int) $total->fetchColumn();

$Npaginas =ceil($total/$registros);

# Creacion de la parte superior de la tabla #
$tabla.='
<div class="table-container">
    <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
        <thead>
            <tr class="has-text-centered">
                <th>#</th>
                <th>Nombre</th>
                <th>Ubicación</th>
                <th>Productos</th>';
                
                ##
                if(!isset($busqueda) || $busqueda==""){
                    // MODIFICADO: Ahora solo es una columna para "Opciones"
                    $tabla.='<th>Opciones</th>';
                }

$tabla.='</tr>
        </thead>
        <tbody>
';

# Mostrar los registros en la tabla # 
if($total>=1 && $pagina<=$Npaginas){
    $contador=$inicio+1;
    $pag_inicio=$inicio+1;
    foreach($datos as $rows){
        $tabla.='
            <tr class="has-text-centered" >
                <td>'.$contador.'</td>
                <td>'.$rows['categoria_nombre'].'</td>
                <td>'.substr($rows['categoria_ubicacion'],0,25).'</td>
                <td>
                    <a href="index.php?vista=product_category&category_id='.$rows['categoria_id'].'" class="button is-link is-small">
                        <span class="icon is-small"><i class="fas fa-eye" aria-hidden="true"></i></span>
                        <span>Ver productos</span>
                    </a>
                </td>';
                
                if(!isset($busqueda) || $busqueda==""){
                    // MODIFICADO: Menú desplegable para "Opciones"
                    $tabla.='
                        <td>
                            <div class="dropdown is-right is-hoverable">
                                <div class="dropdown-trigger">
                                    <button class="button is-small is-warning" aria-haspopup="true" aria-controls="dropdown-menu-cat-'.$rows['categoria_id'].'">
                                        <span>Acciones</span>
                                        <span class="icon is-small">
                                            <i class="fas fa-angle-down" aria-hidden="true"></i>
                                        </span>
                                    </button>
                                </div>
                                <div class="dropdown-menu" id="dropdown-menu-cat-'.$rows['categoria_id'].'" role="menu">
                                    <div class="dropdown-content">
                                        <a href="index.php?vista=category_update&category_id_up='.$rows['categoria_id'].'" class="dropdown-item">
                                            <span class="icon is-small"><i class="fas fa-pencil-alt" aria-hidden="true"></i></span>
                                            <span>Actualizar</span>
                                        </a>
                                        <a href="#" class="dropdown-item js-delete-button has-text-danger" data-id="'.$rows['categoria_id'].'">
                                            <span class="icon is-small has-text-danger"><i class="fas fa-trash" aria-hidden="true"></i></span>
                                            <span>Eliminar</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </td>';
                }
            
        $tabla.='</tr>';
        $contador++;
    }
    $pag_final=$contador-1;
}else{
    # No hay registros en la tabla #
    if($total>=1){
        // MODIFICADO: Ajuste de colspan
        $colspan = (!isset($busqueda) || $busqueda=="") ? 5 : 4;

        $tabla.='
            <tr class="has-text-centered" >
                <td colspan="'.$colspan.'">
                    <a href="'.$url.'1" class="button is-link is-small mt-4 mb-4">
                        Haga clic acá para recargar el listado
                    </a>
                </td>
            </tr>
        ';
    }else{
        // MODIFICADO: Ajuste de colspan
        $colspan = (!isset($busqueda) || $busqueda=="") ? 5 : 4;

        $tabla.='
            <tr class="has-text-centered" >
                <td colspan="'.$colspan.'">
                    No hay registros en el sistema
                </td>
            </tr>
        ';
    }
}


$tabla.='</tbody></table></div>';

if($total>0 && $pagina<=$Npaginas){
    $tabla.='<p class="has-text-right">Mostrando categorías <strong>'.$pag_inicio.'</strong> al <strong>'.$pag_final.'</strong> de un <strong>total de '.$total.'</strong></p>';
}

# Cierra la conexion #
$conexion=null;

# Imprime la tabla #
echo $tabla;

# Mostrar la paginacion #
if($total>=1 && $pagina<=$Npaginas){
    echo paginador_tablas($pagina,$Npaginas,$url,7);
}
?>