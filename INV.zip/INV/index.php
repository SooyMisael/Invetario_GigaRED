<!DOCTYPE html>
<html>
    <head>
        <?php include "./inc/head.php"; ?>
        <link rel="stylesheet" href="estilos.css"> </head>
    <body>
        <div id="notification-container"></div>

        <?php
            if(!isset($_GET['vista']) || $_GET['vista']==""){
                $_GET['vista']="home";
            }

            $vista = $_GET['vista'];

            if(is_file("./vistas/".$vista.".php")){

                $contentClass = "main-content"; // Clase base

                // Si la vista NO es register o login, muestra el navbar
                if($vista != "register" && $vista != "login"){
                    include "./inc/navbar.php";
                } else {
                    // Si ES register o login, añade la clase para pantalla completa
                    $contentClass .= " is-full-width";
                }

                // Imprime el div de contenido con las clases correctas
                echo '<div class="'.$contentClass.'">';
                include "./vistas/".$vista.".php";
                echo '</div>';

                include "./inc/script.php";

            }else{
                include "./vistas/404.php";
            }
        ?>
    </body>
</html>