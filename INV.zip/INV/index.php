<!DOCTYPE html>
<html>
    <head>
        <?php include "./inc/head.php"; ?>
        <link rel="stylesheet" href="estilos.css"> </head>
    <body>
        <div id="notification-container"></div>
    
        <?php
            if(!isset($_GET['vista']) || $_GET['vista']==""){
                $_GET['vista']="home";
            }

            $vista = $_GET['vista'];

            if(is_file("./vistas/".$vista.".php")){

                include "./inc/navbar.php"; // este será tu sidebar

                echo '<div class="main-content">';
                include "./vistas/".$vista.".php"; // contenido dinámico
                echo '</div>';

                include "./inc/script.php";

            }else{
                include "./vistas/404.php";
            }
        ?>
    </body>
</html>