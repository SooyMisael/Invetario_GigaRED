<!DOCTYPE html>
<?php
    ob_start();
    require_once "./inc/session_start.php";

    // Vista por defecto = login
    if (!isset($_GET['vista']) || $_GET['vista']=="") {
        $_GET['vista'] = "login";
    }

    $vista = $_GET['vista'];

    // Si no hay sesión y quiere entrar a algo distinto de login → lo mando a login
    if (!isset($_SESSION['id']) && $vista != "login") {
        header("Location: index.php?vista=login");
        exit();
    }

    // Si hay sesión y entra a login → lo mando al home
    if (isset($_SESSION['id']) && $vista == "login") {
        header("Location: index.php?vista=home");
        exit();
    }
    ?>

<html>
    <head>
        <?php include "./inc/head.php"; ?>
        <link rel="stylesheet" href="estilos.css">
    </head>

    <body>
        <div id="notification-container"></div>

        <?php
            
            $vista = $_GET['vista'];

            if (is_file("./vistas/".$vista.".php")) {

                $contentClass = "main-content";

                if ($vista != "register" && $vista != "login") {
                    include "./inc/navbar.php";
                } else {
                    $contentClass .= " is-full-width";
                }

                echo '<div class="'.$contentClass.'">';
                include "./vistas/".$vista.".php";
                echo '</div>';

                include "./inc/script.php";

            } else {
                include "./vistas/404.php";
            }
        ?>
    </body>

</html>
<?php ob_end_flush(); ?>