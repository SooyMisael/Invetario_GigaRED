<?php
require_once "main.php";
// session_start(); // Si necesitas verificar que sea admin aquí

$id = limpiar_cadena($_GET['product_id_restore']);

$pdo = conexion();

// Verificar si existe (incluso si está eliminado)
$check = $pdo->prepare("SELECT producto_id FROM producto WHERE producto_id = :id");
$check->execute([':id' => $id]);

if($check->rowCount() == 1){
    $restaurar = $pdo->prepare("UPDATE producto SET producto_eliminado = 0 WHERE producto_id = :id");
    $restaurar->execute([':id' => $id]);
    
    if($restaurar->rowCount() == 1){
        header("Location: ../index.php?vista=papeleria&restored=ok");
    } else {
        header("Location: ../index.php?vista=papeleria&restored=error");
    }
}
$pdo = null;
?>