<div class="container is-fluid mb-6">
    <h1 class="title has-text-danger">Papelera de Reciclaje</h1>
    <h2 class="subtitle">Restaurar productos eliminados</h2>
</div>

<div class="container pb-6 pt-6">
    <?php
        require_once "./php/main.php";

        if(!isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin'){
            echo '<div class="notification is-danger">No tienes permisos para acceder a esta área.</div>';
            exit();
        }

        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $inicio = ($pagina>0) ? (($pagina * 15)-15) : 0;
        
        $conexion = conexion();

        
        $consulta = "SELECT producto_id, producto_nombre, producto_codigo FROM producto WHERE producto_eliminado = 1 ORDER BY producto_nombre ASC LIMIT $inicio, 15";
        $datos = $conexion->query($consulta);
        $datos = $datos->fetchAll();

        if(count($datos) > 0){
            echo '<div class="table-container">
                <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr class="has-text-centered">
                            <th>Código</th>
                            <th>Nombre</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>';
            
            foreach($datos as $rows){
                echo '<tr class="has-text-centered">
                        <td>'.$rows['producto_codigo'].'</td>
                        <td>'.$rows['producto_nombre'].'</td>
                        <td>
                            <a href="./php/producto_restaurar.php?product_id_restore='.$rows['producto_id'].'" class="button is-success is-small">
                                <i class="fas fa-trash-restore"></i> &nbsp; Restaurar
                            </a>
                        </td>
                      </tr>';
            }
            echo '</tbody></table></div>';
        } else {
            echo '<p class="has-text-centered">No hay productos en la papelera.</p>';
        }
    ?>
</div>