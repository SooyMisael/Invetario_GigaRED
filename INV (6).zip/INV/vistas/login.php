<div class="container pb-6 pt-6">

    <div class="form-rest mb-6 mt-6"></div>

    <div class="login-form-container">
        
        <div class="has-text-centered mb-4">
            <span class="icon is-large has-text-info">
                <i class="fas fa-user fa-3x"></i>
            </span>
        </div>
        
        <h2 class="title is-4 has-text-centered has-text-dark mb-2">
            Iniciar sesión
        </h2>
        <p class="subtitle is-6 has-text-centered has-text-grey mb-5">
            Ingresa tu correo y contraseña.
        </p>

        <form action="./php/login_ingresar.php" method="POST" class="FormularioAjax" autocomplete="off">

            <div class="field">
                <div class="control has-icons-left">
                    <input class="input" type="email" name="login_email" maxlength="100" placeholder="Email" required >
                    <span class="icon is-small is-left">
                        <i class="fas fa-envelope"></i>
                    </span>
                </div>
            </div>

            <div class="field">
                <div class="control has-icons-left">
                    <input class="input" type="password" name="login_clave" maxlength="100" placeholder="Contraseña" required >
                    <span class="icon is-small is-left">
                        <i class="fas fa-lock"></i>
                    </span>
                </div>
            </div>
            
            <p class="has-text-centered mt-5">
                <button type="submit" class="button is-info is-fullwidth has-text-weight-bold">INGRESAR</button>
            </p>

        </form>
    </div>
</div>