<div class="container is-fluid">
    <h1 class="title">¡Bienvenido!</h1> <br>

    <div class="columns is-centered mt-4 mb-6">
        <div class="column is-half">
            <?php
                require_once "./php/main.php";
                require_once "./inc/session_start.php";

                if(isset($_POST['modulo_buscador'])){
                    require_once "./php/buscador.php";
                }

                if(!isset($_SESSION['busqueda_producto']) || empty($_SESSION['busqueda_producto'])){
            ?>
            <form action="" method="POST" autocomplete="off">
                <input type="hidden" name="modulo_buscador" value="producto">
                
                <input type="hidden" name="vista_actual" value="home">
                
                <div class="field has-addons">
                    <div class="control is-expanded">
                        <input class="input" type="text" name="txt_buscador" placeholder="¿Qué estás buscando?" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]{1,30}" maxlength="30">
                    </div>
                    <div class="control">
                        <button class="button is-info" type="submit">Buscar</button>
                    </div>
                </div>
            </form>
            <?php } else { ?>
            <form action="" method="POST" autocomplete="off" class="has-text-centered">
                <input type="hidden" name="modulo_buscador" value="producto">
                <input type="hidden" name="eliminar_buscador" value="producto">
                
                <input type="hidden" name="vista_actual" value="home">
                
                <p>Estás buscando <strong>“<?php echo $_SESSION['busqueda_producto']; ?>”</strong></p>
                <button type="submit" class="button is-danger mt-2">Eliminar búsqueda</button>
            </form>
            <?php } ?>
        </div>
    </div>


    <div class="columns is-multiline mt-5">

        <div class="column is-one-third">
            <a href="index.php?vista=product_new">
                <div class="dashboard-box" style="background-color: gray;">
                    <span class="icon is-large">
                        <i class="fas fa-plus fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Agregar nuevo producto</h2>
                </div>
            </a>
        </div>

        <div class="column is-one-third">
            <a href="index.php?vista=product_list">
                <div class="dashboard-box" style="background-color: gray;">
                    <span class="icon is-large">
                        <i class="fas fa-list fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Lista de Productos</h2>
                </div>
            </a>
        </div>

        <div class="column is-one-third">
            <a href="./php/exportar_pdf.php" target="_blank">
                <div class="dashboard-box" style="background-color: gray;">
                    <span class="icon is-large">
                        <i class="fas fa-file-pdf fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Generar PDF de productos</h2>
                </div>
            </a>
        </div>
        
        <div class="column is-one-third">
            <a href="index.php?vista=ultimos_movimientos">
                <div class="dashboard-box" style="background-color: gray;">
                    <span class="icon is-large">
                        <i class="fas fa-history fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Ultimos Movimientos</h2>
                </div>
            </a>
        </div>

        <div class="column is-one-third">
            <a href="index.php?vista=category_new">
                <div class="dashboard-box" style="background-color: gray;">
                    <span class="icon is-large">
                        <i class="fas fa-plus fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Agregar Categoria y Ubicacion</h2>
                </div>
            </a>
        </div>

        <div class="column is-one-third">
            <a href="index.php?vista=product_category">
                <div class="dashboard-box" style="background-color: gray;">
                    <span class="icon is-large">
                        <i class="fas fa-list fa-3x"></i>
                    </span>
                    <h2 class="subtitle mt-3">Ver Categorias</h2>
                </div>
            </a>
        </div>  
    
    </div>
</div>



<button id="toggleLowStockBtn" class="button is-danger is-rounded boton-bajo-stock">
    <i class="fas fa-exclamation-triangle"></i>&nbsp; Productos por agotarse
</button>

<div id="lowStockContainer" class="low-stock-container">
    <div class="carousel">
        <?php
           
            $conexion = conexion();

            $consulta = "
                SELECT 
                    producto.producto_id,
                    producto.producto_nombre,
                    producto.producto_stock,
                    (SELECT nombre_archivo 
                        FROM producto_imagenes 
                        WHERE producto_imagenes.producto_id = producto.producto_id 
                        ORDER BY orden ASC, imagen_id ASC 
                        LIMIT 1) AS imagen_principal
                FROM producto
                WHERE producto.producto_stock = 1
                ORDER BY producto.producto_nombre ASC
            ";

            $query = $conexion->query($consulta);

            if($query->rowCount() > 0){
                foreach($query as $producto){
                    $imagen = (!empty($producto['imagen_principal']) && file_exists("./img/producto/".$producto['imagen_principal']))
                        ? "./img/producto/".$producto['imagen_principal']
                        : "./img/producto.png";
        ?>
                <div class="carousel-item">
                    <img src="<?php echo $imagen; ?>" alt="<?php echo htmlspecialchars($producto['producto_nombre']); ?>">
                    <p class="has-text-centered mt-2">
                        <?php echo htmlspecialchars($producto['producto_nombre']); ?><br>
                        <span class="tag is-danger is-light">cantidad: 1</span>
                    </p>
                </div>
        <?php
                }
            } else {
                echo "<p class='has-text-centered'>No hay productos a punto de agotarse.</p>";
            }

            $conexion = null;
        ?>
    </div>
</div>

<script>
document.getElementById('toggleLowStockBtn').addEventListener('click', function() {
    const container = document.getElementById('lowStockContainer');
    container.classList.toggle('active');
});
</script>



<style>

.boton-bajo-stock {
    position: fixed;
    bottom: 25px;
    right: 25px;
    background-color: #e63946;
    color: white;
    font-weight: bold;
    border: none;
    box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    transition: transform 0.2s, box-shadow 0.2s;
    z-index: 999;
    border-radius: 8px; 
}

.boton-bajo-stock:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 16px rgba(0,0,0,0.3);
}


.low-stock-container {
    display: none;
    position: fixed;
    bottom: 90px;
    right: 25px;
    width: 350px;
    max-height: 300px;
    overflow-y: auto;
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 20px rgba(0,0,0,0.25);
    padding: 15px;
    z-index: 998;
}

.low-stock-container.active {
    display: block;
}


.carousel {
    display: flex;
    overflow-x: auto;
    gap: 15px;
    scroll-behavior: smooth;
    padding-bottom: 10px;
}

.carousel-item {
    flex: 0 0 auto;
    width: 120px;
    background: #f4f4f4;
    border-radius: 8px;
    padding: 10px;
    text-align: center;
    transition: transform 0.2s;
}

.carousel-item img {
    width: 100%;
    height: 80px;
    object-fit: cover;
    border-radius: 6px;
}

.carousel-item:hover {
    transform: scale(1.05);
}



.dashboard-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    color: white;
    padding: 20px;
    border-radius: 12px;
    transition: transform 0.2s, box-shadow 0.2s;
    cursor: pointer;
    height: 120px;
}


.dashboard-box .icon {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    background: rgba(255, 255, 255, 0);
    height: 100%;
    border-radius: 8px 0 0 8px;
}


.dashboard-box h2 {
    flex: 2;
    margin: 0;
    text-align: center;
    font-size: 1.1rem;
    padding: 0 10px;
    color: white !important; 
}


.dashboard-box:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(22, 22, 21, 0.46);
}


.has-background-orange {
    background-color: orange !important;
}

.has-background-gray {
    background-color: gray !important;
}
</style>