<?php
require_once "inc/session_start.php";
?>

<nav class="navbar is-light is-hidden-desktop" role="navigation" aria-label="main navigation">
    <div class="container">
        <div class="navbar-brand">
            <a class="navbar-item" href="index.php?vista=home">
                <strong>GR INGENIERÍA</strong> 
            </a>
            <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="mobileNavbarMenu">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
            </a>
        </div>

        <div id="mobileNavbarMenu" class="navbar-menu">
            <div class="navbar-start">
                <p class="navbar-item has-text-weight-bold">PRODUCTOS</p>
                <a class="navbar-item" href="index.php?vista=product_new">
                    <span class="icon"><i class="fas fa-plus"></i></span>
                    <span>Nuevo</span>
                </a>
                <a class="navbar-item" href="index.php?vista=product_list">
                    <span class="icon"><i class="fas fa-list"></i></span>
                    <span>Lista</span>
                </a>
                <a class="navbar-item" href="index.php?vista=product_category">
                    <span class="icon"><i class="fas fa-tag"></i></span>
                    <span>Por categoría</span>
                </a>
                <a class="navbar-item" href="index.php?vista=product_search">
                    <span class="icon"><i class="fas fa-search"></i></span>
                    <span>Buscar producto</span>
                </a>
                
                <hr class="navbar-divider">
                
                <p class="navbar-item has-text-weight-bold">CATEGORÍAS</p>
                <a class="navbar-item" href="index.php?vista=category_new">
                    <span class="icon"><i class="fas fa-plus"></i></span>
                    <span>Nueva</span>
                </a>
                <a class="navbar-item" href="index.php?vista=category_list">
                    <span class="icon"><i class="fas fa-list"></i></span>
                    <span>Lista</span>
                </a>

                <?php if(isset($_SESSION['rol']) && $_SESSION['rol'] == 'admin'): ?>
                    <hr class="navbar-divider">
                    <p class="navbar-item has-text-weight-bold has-text-danger">ADMINISTRACIÓN</p>
                    
                    <a class="navbar-item" href="index.php?vista=ultimos_movimientos">
                        <span class="icon has-text-info"><i class="fas fa-history"></i></span>
                        <span>Historial de Movimientos</span>
                    </a>

                    <a class="navbar-item" href="index.php?vista=admin_trash">
                        <span class="icon has-text-danger"><i class="fas fa-trash-restore"></i></span>
                        <span class="has-text-danger">Papelera / Restaurar</span>
                    </a>
                <?php endif; ?>
                </div>
            
            <div class="navbar-end">
                <div class="navbar-item has-dropdown is-hoverable">
                    <a class="navbar-link">
                        <span class="icon"><i class="fas fa-user-circle"></i></span>
                        <span>&nbsp; <?php echo $_SESSION['nombre']; ?></span>
                    </a>
                    <div class="navbar-dropdown is-right">
                        <hr class="navbar-divider">
                        <a class="navbar-item has-text-danger" href="index.php?vista=logout">
                            <span class="icon"><i class="fas fa-sign-out-alt"></i></span>
                            <span>Cerrar Sesión</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="menu-sidebar is-hidden-touch">
    <div class="menu-logo">
        <a href="index.php?vista=home">
            <img src="./img/GIGA-RED.jpeg" alt="GR Ingeniería Logo">
        </a>
    </div>

    <p class="menu-label">PRODUCTOS</p>
    <ul class="menu-list">
        <li><a href="index.php?vista=product_new"><i class="fas fa-plus fa-fw"></i> &nbsp; Nuevo</a></li>
        <li><a href="index.php?vista=product_list"><i class="fas fa-list fa-fw"></i> &nbsp; Lista</a></li>
        <li><a href="index.php?vista=product_category"><i class="fas fa-tag fa-fw"></i> &nbsp; Por categoría</a></li>
        <li><a href="index.php?vista=product_search"><i class="fas fa-search fa-fw"></i> &nbsp; Buscar Producto</a></li>
    </ul>

    <p class="menu-label">CATEGORÍAS</p>
    <ul class="menu-list">
        <li><a href="index.php?vista=category_new"><i class="fas fa-plus fa-fw"></i> &nbsp; Nueva</a></li>
        <li><a href="index.php?vista=category_list"><i class="fas fa-list fa-fw"></i> &nbsp; Lista</a></li>
    </ul>
    
    <?php if(isset($_SESSION['rol']) && $_SESSION['rol'] == 'admin'): ?>
        <p class="menu-label has-text-danger">ADMINISTRACIÓN</p>
        <ul class="menu-list">
            
            <li>
                <a href="index.php?vista=ultimos_movimientos">
                    <i class="fas fa-history fa-fw has-text-info"></i> &nbsp; Historial de Movimientos
                </a>
            </li>


        </ul>
    <?php endif; ?>
    <p class="menu-label">USUARIO</p>
    <ul class="menu-list">
        <li>
            <a href="#">
                <i class="fas fa-user-circle fa-fw"></i> &nbsp; <?php echo $_SESSION['nombre']; ?>
            </a>
        </li>
        <li>
            <a href="index.php?vista=logout" class="has-text-danger">
                <i class="fas fa-sign-out-alt fa-fw"></i> &nbsp; Cerrar Sesión
            </a>
        </li>
    </ul>
</div>