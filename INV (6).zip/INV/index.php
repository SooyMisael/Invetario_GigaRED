<?php
    ob_start();
    require_once "./inc/session_start.php";

    if (!isset($_GET['vista']) || $_GET['vista']=="") {
        $_GET['vista'] = "login";
    }

    $vista = $_GET['vista'];

    if (!isset($_SESSION['id']) && $vista != "login" && $vista != "register") {
        header("Location: index.php?vista=login");
        exit();
    }

    if (isset($_SESSION['id']) && ($vista == "login" || $vista == "register")) {
        header("Location: index.php?vista=home");
        exit();
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include "./inc/head.php"; ?>
        <link rel="stylesheet" href="estilos.css">
    </head>
    <body>
        <div id="notification-container"></div>

        <?php if(isset($_SESSION['id'])): ?>
        <div id="session-timer" class="tag is-link is-light is-medium">
            <span class="icon has-text-info">
                <i class="fas fa-stopwatch"></i>
            </span>
            <span style="font-weight: bold;">Sesión: </span>
            <span id="timer-display" style="font-weight: bold; min-width: 45px;">02:00</span>
        </div>
        <?php endif; ?>

        <?php
            if (is_file("./vistas/".$vista.".php")) {

                $contentClass = "main-content";

                if ($vista != "register" && $vista != "login") {
                    include "./inc/navbar.php";
                } else {
                    $contentClass .= " is-full-width";
                }

                echo '<div class="'.$contentClass.'">';
                include "./vistas/".$vista.".php";
                echo '</div>';

                include "./inc/script.php";

            } else {
                include "./vistas/404.php";
            }
        ?>
    </body>
</html>
<?php ob_end_flush(); ?>